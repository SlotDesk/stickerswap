import { Home, Map, BookOpen, ArrowLeftRight, User } from 'lucide-react'

const TABS = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'map', label: 'Karte', icon: Map },
  { id: 'album', label: 'Album', icon: BookOpen },
  { id: 'trades', label: 'Tauschen', icon: ArrowLeftRight },
  { id: 'profile', label: 'Profil', icon: User },
]

export default function Layout({ tab, setTab, badge, children }) {
  return (
    <div className="min-h-dvh lg:flex relative z-10">
      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex flex-col w-60 shrink-0 border-r border-white/10 bg-card/60 backdrop-blur sticky top-0 h-dvh p-5">
        <div className="flex items-center gap-2 mb-8">
          <span className="text-2xl">⚽</span>
          <span className="font-display text-2xl text-gold">StickerSwap 26</span>
        </div>
        <nav className="flex flex-col gap-1" aria-label="Hauptnavigation">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              aria-current={tab === id ? 'page' : undefined}
              className={`relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-gold ${
                tab === id ? 'bg-gold/15 text-gold' : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <Icon size={18} />
              {label}
              {id === 'trades' && badge > 0 && (
                <span className="ml-auto bg-missing text-white text-[10px] font-bold rounded-full min-w-5 h-5 px-1 flex items-center justify-center">
                  {badge}
                </span>
              )}
            </button>
          ))}
        </nav>
        <p className="mt-auto text-[10px] text-white/25">
          Inoffizielles Fan-Projekt · Testphase
        </p>
      </aside>

      {/* Inhalt */}
      <main className="flex-1 pb-24 lg:pb-8 max-w-3xl lg:max-w-none mx-auto w-full">{children}</main>

      {/* Bottom-Nav Mobile */}
      <nav
        className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-card/90 backdrop-blur border-t border-white/10 flex pb-[env(safe-area-inset-bottom)]"
        aria-label="Hauptnavigation"
      >
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            aria-current={tab === id ? 'page' : undefined}
            className={`relative flex-1 flex flex-col items-center gap-0.5 py-2.5 text-[10px] font-medium focus-visible:outline focus-visible:outline-gold ${
              tab === id ? 'text-gold' : 'text-white/50'
            }`}
          >
            <Icon size={20} />
            {label}
            {id === 'trades' && badge > 0 && (
              <span className="absolute top-1 right-1/2 translate-x-4 bg-missing text-white text-[9px] font-bold rounded-full min-w-4 h-4 px-0.5 flex items-center justify-center">
                {badge}
              </span>
            )}
          </button>
        ))}
      </nav>
    </div>
  )
}
