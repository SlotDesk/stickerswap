import { useCallback, useEffect, useRef, useState } from 'react'
import { Search, MapPin, X, Loader2 } from 'lucide-react'

/**
 * LocationPicker – Interaktive Weltkarte via OpenStreetMap + Nominatim-Suche.
 * Gibt { name, lat, lng } via onSelect zurück.
 */
export default function LocationPicker({ initial, onSelect, onClose }) {
  const mapRef = useRef(null)
  const leafletRef = useRef(null)
  const markerRef = useRef(null)

  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [searching, setSearching] = useState(false)
  const [selected, setSelected] = useState(initial ?? null)
  const [leafletReady, setLeafletReady] = useState(false)
  const searchTimer = useRef(null)

  // Leaflet dynamisch laden
  useEffect(() => {
    if (window.L) { setLeafletReady(true); return }

    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css'
    document.head.appendChild(link)

    const script = document.createElement('script')
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js'
    script.onload = () => setLeafletReady(true)
    document.head.appendChild(script)
  }, [])

  // Karte initialisieren sobald Leaflet geladen
  useEffect(() => {
    if (!leafletReady || !mapRef.current || leafletRef.current) return
    const L = window.L

    const startLat = initial?.lat ?? 48.5
    const startLng = initial?.lng ?? 10
    const startZoom = initial ? 8 : 4

    const map = L.map(mapRef.current, { zoomControl: true }).setView([startLat, startLng], startZoom)
    leafletRef.current = map

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '© OpenStreetMap, © CARTO',
      maxZoom: 19,
    }).addTo(map)

    // Custom Gold-Marker
    const icon = L.divIcon({
      className: '',
      html: `<div style="width:24px;height:24px;background:#FFD700;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:3px solid #0a0e1a;box-shadow:0 2px 8px rgba(0,0,0,0.5)"></div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 24],
    })

    if (initial?.lat) {
      markerRef.current = L.marker([initial.lat, initial.lng], { icon }).addTo(map)
    }

    map.on('click', (e) => {
      const { lat, lng } = e.latlng
      placeMarker(map, icon, lat, lng)
      reverseGeocode(lat, lng)
    })

    return () => { map.remove(); leafletRef.current = null }
  }, [leafletReady]) // eslint-disable-line react-hooks/exhaustive-deps

  const placeMarker = useCallback((map, icon, lat, lng) => {
    const L = window.L
    if (markerRef.current) markerRef.current.remove()
    markerRef.current = L.marker([lat, lng], { icon: icon ?? L.divIcon({
      className: '',
      html: `<div style="width:24px;height:24px;background:#FFD700;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:3px solid #0a0e1a;box-shadow:0 2px 8px rgba(0,0,0,0.5)"></div>`,
      iconSize: [24, 24], iconAnchor: [12, 24],
    })}).addTo(map ?? leafletRef.current)
  }, [])

  const reverseGeocode = useCallback(async (lat, lng) => {
    try {
      const r = await fetch(
        `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=de`,
        { headers: { 'Accept-Language': 'de' } }
      )
      const d = await r.json()
      const city =
        d.address?.city || d.address?.town || d.address?.village ||
        d.address?.county || d.address?.state || d.display_name?.split(',')[0]
      const loc = { name: city ?? `${lat.toFixed(3)}, ${lng.toFixed(3)}`, lat, lng }
      setSelected(loc)
    } catch {
      setSelected({ name: `${lat.toFixed(3)}, ${lng.toFixed(3)}`, lat, lng })
    }
  }, [])

  // Freitext-Suche (Nominatim) mit Debounce
  useEffect(() => {
    if (!query.trim() || query.length < 2) { setResults([]); return }
    clearTimeout(searchTimer.current)
    searchTimer.current = setTimeout(async () => {
      setSearching(true)
      try {
        const r = await fetch(
          `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=6&accept-language=de`,
          { headers: { 'Accept-Language': 'de' } }
        )
        const data = await r.json()
        setResults(data)
      } catch { setResults([]) }
      setSearching(false)
    }, 400)
  }, [query])

  const pickResult = (res) => {
    const lat = parseFloat(res.lat)
    const lng = parseFloat(res.lon)
    const name = res.address?.city || res.address?.town || res.address?.village || res.display_name?.split(',')[0]
    const loc = { name, lat, lng }
    setSelected(loc)
    setResults([])
    setQuery('')
    if (leafletRef.current) {
      placeMarker(null, null, lat, lng)
      leafletRef.current.setView([lat, lng], 9)
    }
  }

  return (
    <div className="flex flex-col h-full">
      {/* Suchleiste */}
      <div className="relative p-3 pb-0">
        <div className="flex items-center gap-2 bg-bg border border-white/15 rounded-xl px-3 focus-within:border-gold">
          {searching ? <Loader2 size={15} className="text-white/40 animate-spin shrink-0" /> : <Search size={15} className="text-white/40 shrink-0" />}
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Stadt oder Ort suchen…"
            className="flex-1 bg-transparent py-2.5 text-sm outline-none placeholder:text-white/30"
            autoComplete="off"
          />
          {query && (
            <button onClick={() => { setQuery(''); setResults([]) }} className="text-white/40 hover:text-white">
              <X size={14} />
            </button>
          )}
        </div>

        {/* Suchergebnisse Dropdown */}
        {results.length > 0 && (
          <div className="absolute left-3 right-3 top-full mt-1 bg-card2 border border-white/15 rounded-xl overflow-hidden z-50 shadow-xl">
            {results.map((r, i) => (
              <button
                key={i}
                onClick={() => pickResult(r)}
                className="w-full flex items-center gap-2 px-3 py-2.5 text-sm hover:bg-white/10 text-left border-b border-white/5 last:border-0"
              >
                <MapPin size={13} className="text-gold shrink-0" />
                <span className="truncate">{r.display_name}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Karte */}
      <div ref={mapRef} className="flex-1 min-h-[260px] mt-2 rounded-xl overflow-hidden" />

      {/* Auswahl bestätigen */}
      {selected && (
        <div className="p-3 pt-2 flex items-center gap-3">
          <div className="flex-1 bg-bg/60 border border-gold/30 rounded-xl px-3 py-2 text-sm">
            <span className="text-white/50 text-xs">Gewählter Ort</span>
            <p className="font-medium text-gold truncate">{selected.name}</p>
          </div>
          <button
            onClick={() => onSelect(selected)}
            className="bg-gold text-bg font-bold rounded-xl px-4 py-2.5 text-sm hover:brightness-110 shrink-0 focus-visible:outline focus-visible:outline-2 focus-visible:outline-white"
          >
            Bestätigen
          </button>
        </div>
      )}
      {!selected && (
        <p className="text-center text-xs text-white/35 p-3">Klick auf die Karte oder suche einen Ort</p>
      )}
    </div>
  )
}
