import { useEffect, useState } from 'react'
import { X, Share, MoreVertical } from 'lucide-react'

/**
 * Zeigt einen "Zum Homescreen hinzufügen"-Banner.
 * - Android/Chrome: nutzt das beforeinstallprompt-Event (nativer Prompt)
 * - iOS Safari: zeigt manuelle Anleitung (kein API verfügbar)
 * - Wird nach 30 s eingeblendet, verschwindet nach Dismiss für 7 Tage
 */
export default function InstallPrompt() {
  const [show, setShow] = useState(false)
  const [isIOS, setIsIOS] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState(null)

  useEffect(() => {
    // Schon installiert oder bereits dismissed?
    const dismissed = localStorage.getItem('install-dismissed')
    if (dismissed && Date.now() - parseInt(dismissed) < 7 * 24 * 3600 * 1000) return
    // Schon als PWA geöffnet?
    if (window.matchMedia('(display-mode: standalone)').matches) return
    if (window.navigator.standalone) return

    const ios = /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream
    setIsIOS(ios)

    // Android: nativer Prompt abfangen
    const handler = (e) => {
      e.preventDefault()
      setDeferredPrompt(e)
    }
    window.addEventListener('beforeinstallprompt', handler)

    // Nach 30 s einblenden
    const t = setTimeout(() => setShow(true), 30000)

    return () => {
      window.removeEventListener('beforeinstallprompt', handler)
      clearTimeout(t)
    }
  }, [])

  const dismiss = () => {
    setShow(false)
    localStorage.setItem('install-dismissed', Date.now().toString())
  }

  const install = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      if (outcome === 'accepted') dismiss()
    }
  }

  if (!show) return null

  return (
    <div className="fixed bottom-20 lg:bottom-6 inset-x-4 z-50 animate-card">
      <div className="bg-card2 border border-gold/40 rounded-2xl p-4 shadow-2xl max-w-sm mx-auto">
        <div className="flex items-start gap-3">
          <span className="text-3xl shrink-0">⚽</span>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-sm">App zum Homescreen hinzufügen</p>
            <p className="text-xs text-white/55 mt-0.5">
              Schneller Zugriff, kein Browser nötig.
            </p>

            {/* iOS-Anleitung */}
            {isIOS && (
              <div className="mt-2.5 flex flex-col gap-1.5 text-xs text-white/70">
                <Step n={1}>
                  Tippe auf <span className="inline-flex items-center gap-0.5 bg-white/10 px-1.5 py-0.5 rounded font-medium">
                    <Share size={11} className="inline" /> Teilen
                  </span> unten in Safari
                </Step>
                <Step n={2}>
                  Scrolle zu <span className="bg-white/10 px-1.5 py-0.5 rounded font-medium">„Zum Home-Bildschirm"</span>
                </Step>
                <Step n={3}>Tippe auf <span className="bg-white/10 px-1.5 py-0.5 rounded font-medium">„Hinzufügen"</span></Step>
              </div>
            )}

            {/* Android nativer Prompt */}
            {!isIOS && deferredPrompt && (
              <button
                onClick={install}
                className="mt-3 bg-gold text-bg font-bold rounded-xl px-4 py-2 text-xs hover:brightness-110"
              >
                Jetzt installieren
              </button>
            )}

            {/* Android ohne Prompt (z.B. Firefox) */}
            {!isIOS && !deferredPrompt && (
              <div className="mt-2.5 flex flex-col gap-1.5 text-xs text-white/70">
                <Step n={1}>
                  Tippe auf <span className="inline-flex items-center gap-0.5 bg-white/10 px-1.5 py-0.5 rounded font-medium">
                    <MoreVertical size={11} className="inline" /> Menü
                  </span> oben rechts
                </Step>
                <Step n={2}>
                  Wähle <span className="bg-white/10 px-1.5 py-0.5 rounded font-medium">„Zum Startbildschirm"</span>
                </Step>
              </div>
            )}
          </div>
          <button onClick={dismiss} className="text-white/40 hover:text-white shrink-0 -mt-0.5" aria-label="Schließen">
            <X size={18} />
          </button>
        </div>
      </div>
    </div>
  )
}

function Step({ n, children }) {
  return (
    <div className="flex items-start gap-2">
      <span className="w-4 h-4 rounded-full bg-gold/30 text-gold text-[9px] font-bold flex items-center justify-center shrink-0 mt-0.5">{n}</span>
      <span>{children}</span>
    </div>
  )
}
