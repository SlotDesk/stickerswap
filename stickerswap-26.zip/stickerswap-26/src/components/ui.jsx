import { X } from 'lucide-react'
import { stickerCode } from '../lib/constants'

export function Skeleton({ className = '' }) {
  return <div className={`skeleton ${className}`} aria-hidden="true" />
}

export function SkeletonList({ rows = 3, className = '' }) {
  return (
    <div className={`flex flex-col gap-3 ${className}`}>
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-24 w-full" />
      ))}
    </div>
  )
}

export function ProgressRing({ value, max, size = 150, stroke = 11, label }) {
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  const pct = max > 0 ? value / max : 0
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} role="img" aria-label={`${value} von ${max} Stickern`}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#1c2138" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="#FFD700"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - pct)}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          className="ring-stroke"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-3xl text-gold leading-none">{value}</span>
        <span className="text-xs text-white/50">/ {max}</span>
        {label && <span className="text-[10px] text-white/40 mt-0.5">{label}</span>}
      </div>
    </div>
  )
}

export function EmptyState({ emoji = '📭', title, text, action }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-14 px-6 gap-2">
      <div className="text-5xl mb-1">{emoji}</div>
      <h3 className="font-display text-xl text-white/90">{title}</h3>
      {text && <p className="text-sm text-white/50 max-w-xs">{text}</p>}
      {action}
    </div>
  )
}

export function Modal({ open, onClose, title, children }) {
  if (!open) return null
  return (
    <div
      className="fixed inset-0 z-50 flex items-end lg:items-center justify-center bg-black/70 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <div
        className="animate-card w-full lg:max-w-md bg-card border border-white/10 rounded-t-2xl lg:rounded-2xl p-5 max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-2xl">{title}</h3>
          <button onClick={onClose} aria-label="Schließen" className="p-2 rounded-lg hover:bg-white/10 focus-visible:outline focus-visible:outline-gold">
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

export function StickerChips({ nums, color = 'gold', max = 8 }) {
  const shown = nums.slice(0, max)
  const rest = nums.length - shown.length
  const colors = {
    gold: 'bg-gold/15 text-gold border-gold/30',
    match: 'bg-match/10 text-match border-match/30',
    double: 'bg-double/15 text-double border-double/30',
  }
  return (
    <span className="inline-flex flex-wrap gap-1 align-middle">
      {shown.map((n) => (
        <span key={n} className={`font-mono text-[11px] px-1.5 py-0.5 rounded border ${colors[color]}`}>
          {stickerCode(n)}
        </span>
      ))}
      {rest > 0 && <span className="text-[11px] text-white/40 self-center">+{rest}</span>}
    </span>
  )
}

/** Share: Clipboard + Web Share API (mobil) */
export async function shareText(text, toast) {
  try {
    if (navigator.share) {
      await navigator.share({ text })
      return
    }
    await navigator.clipboard.writeText(text)
    toast?.success('In die Zwischenablage kopiert! 📋')
  } catch (e) {
    if (e?.name !== 'AbortError') toast?.error('Teilen hat nicht geklappt.')
  }
}
