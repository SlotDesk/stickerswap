import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'
import { useToast } from './useToast'

export function useMatches() {
  const { user } = useAuth()
  const toast = useToast()
  const [matches, setMatches] = useState(null) // null = lädt

  const reload = useCallback(async () => {
    if (!user) return
    const { data, error } = await supabase.rpc('find_matches', { p_user_id: user.id })
    if (error) {
      toast.error('Matches konnten nicht geladen werden.')
      setMatches([])
    } else {
      setMatches(data ?? [])
    }
  }, [user]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    reload()
  }, [reload])

  return { matches, reload }
}

export function useTrades() {
  const { user } = useAuth()
  const toast = useToast()
  const [trades, setTrades] = useState(null)

  const reload = useCallback(async () => {
    if (!user) return
    // Bots akzeptieren offene Anfragen, die älter als 30 s sind
    await supabase.rpc('process_bot_trades').then(() => {}, () => {})
    const { data, error } = await supabase
      .from('trades')
      .select(
        '*, requester:profiles!trades_requester_id_fkey(id,name,avatar_emoji,city), partner:profiles!trades_partner_id_fkey(id,name,avatar_emoji,city)',
      )
      .or(`requester_id.eq.${user.id},partner_id.eq.${user.id}`)
      .order('created_at', { ascending: false })
    if (error) {
      toast.error('Tauschanfragen konnten nicht geladen werden.')
      setTrades([])
    } else {
      setTrades(data ?? [])
    }
  }, [user]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    reload()
  }, [reload])

  // Realtime: neue/aktualisierte Trades, die mich betreffen
  useEffect(() => {
    if (!user) return
    const channel = supabase
      .channel('trades-live')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'trades', filter: `partner_id=eq.${user.id}` },
        () => reload(),
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'trades', filter: `requester_id=eq.${user.id}` },
        () => reload(),
      )
      .subscribe()
    return () => {
      supabase.removeChannel(channel)
    }
  }, [user, reload])

  const accept = useCallback(
    async (id) => {
      const { error } = await supabase.rpc('accept_trade', { p_trade_id: id })
      if (error) toast.error('Annehmen fehlgeschlagen: ' + error.message)
      else toast.success('Tausch angenommen! Inventar wurde aktualisiert. 🎉')
      await reload()
      return !error
    },
    [reload, toast],
  )

  const decline = useCallback(
    async (id) => {
      const { error } = await supabase
        .from('trades')
        .update({ status: 'declined', updated_at: new Date().toISOString() })
        .eq('id', id)
      if (error) toast.error('Ablehnen fehlgeschlagen.')
      await reload()
    },
    [reload, toast],
  )

  const request = useCallback(
    async ({ partnerId, give, get, message }) => {
      const { error } = await supabase.from('trades').insert({
        requester_id: user.id,
        partner_id: partnerId,
        give_stickers: give,
        get_stickers: get,
        message,
      })
      if (error) {
        toast.error('Anfrage konnte nicht gesendet werden.')
        return false
      }
      toast.success('Tauschanfrage gesendet! 🤝')
      await reload()
      return true
    },
    [user, reload, toast],
  )

  const incomingPending = (trades ?? []).filter(
    (t) => t.partner_id === user?.id && t.status === 'pending',
  )

  return { trades, reload, accept, decline, request, incomingPending }
}
