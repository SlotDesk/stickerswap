import { useCallback, useEffect, useRef, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'
import { useToast } from './useToast'
import { TOTAL_STICKERS } from '../lib/constants'

/**
 * Inventar als Map { sticker_no -> 'have' | 'double' } (fehlend = kein Eintrag).
 * Quick-Tap-Zyklus: fehlend -> have -> double -> fehlend.
 * Writes werden 800 ms gebatcht (upsert für have/double, delete für fehlend).
 */
export function useStickers() {
  const { user } = useAuth()
  const toast = useToast()
  const [statusMap, setStatusMap] = useState(new Map())
  const [loading, setLoading] = useState(true)
  const pending = useRef(new Map()) // sticker_no -> 'have' | 'double' | null (löschen)
  const timer = useRef(null)

  useEffect(() => {
    if (!user) return
    let active = true
    ;(async () => {
      setLoading(true)
      const { data, error } = await supabase
        .from('sticker_status')
        .select('sticker_no,status')
        .eq('user_id', user.id)
      if (!active) return
      if (error) {
        toast.error('Sammlung konnte nicht geladen werden. Bist du online?')
      } else {
        setStatusMap(new Map(data.map((r) => [r.sticker_no, r.status])))
      }
      setLoading(false)
    })()
    return () => {
      active = false
    }
  }, [user]) // eslint-disable-line react-hooks/exhaustive-deps

  const flush = useCallback(async () => {
    if (!user || pending.current.size === 0) return
    const batch = pending.current
    pending.current = new Map()

    const upserts = []
    const deletes = []
    for (const [no, status] of batch) {
      if (status === null) deletes.push(no)
      else upserts.push({ user_id: user.id, sticker_no: no, status })
    }

    const errs = []
    if (upserts.length) {
      const { error } = await supabase.from('sticker_status').upsert(upserts)
      if (error) errs.push(error)
    }
    if (deletes.length) {
      const { error } = await supabase
        .from('sticker_status')
        .delete()
        .eq('user_id', user.id)
        .in('sticker_no', deletes)
      if (error) errs.push(error)
    }
    if (errs.length) {
      // Änderungen zurück in die Queue, nächster Tap versucht es erneut
      for (const [no, status] of batch) {
        if (!pending.current.has(no)) pending.current.set(no, status)
      }
      toast.error('Speichern fehlgeschlagen – wird beim nächsten Tippen erneut versucht.')
    }
  }, [user, toast])

  const queue = useCallback(
    (no, status) => {
      pending.current.set(no, status)
      clearTimeout(timer.current)
      timer.current = setTimeout(flush, 800)
    },
    [flush],
  )

  // Beim Verlassen der Seite noch offene Writes senden
  useEffect(() => {
    const onHide = () => flush()
    window.addEventListener('pagehide', onHide)
    return () => {
      window.removeEventListener('pagehide', onHide)
      flush()
    }
  }, [flush])

  const cycle = useCallback(
    (no) => {
      setStatusMap((prev) => {
        const next = new Map(prev)
        const cur = prev.get(no)
        const nxt = cur === undefined ? 'have' : cur === 'have' ? 'double' : undefined
        if (nxt === undefined) next.delete(no)
        else next.set(no, nxt)
        queue(no, nxt ?? null)
        return next
      })
    },
    [queue],
  )

  /** Bulk: ganze Sektion als 'have' markieren (vorhandene/doppelte bleiben) */
  const markSectionHave = useCallback(
    (from, to) => {
      setStatusMap((prev) => {
        const next = new Map(prev)
        for (let no = from; no <= to; no++) {
          if (!next.has(no)) {
            next.set(no, 'have')
            queue(no, 'have')
          }
        }
        return next
      })
    },
    [queue],
  )

  const counts = (() => {
    let have = 0
    let double_ = 0
    for (const s of statusMap.values()) {
      if (s === 'have') have++
      else double_++
    }
    return { have, double: double_, owned: have + double_, missing: TOTAL_STICKERS - have - double_ }
  })()

  return { statusMap, setStatusMap, cycle, markSectionHave, counts, loading }
}
