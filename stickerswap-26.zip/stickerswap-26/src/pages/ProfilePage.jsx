import { useMemo, useState } from 'react'
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts'
import { LogOut, Send, Loader2, Share2, MapPin } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { useToast } from '../hooks/useToast'
import { AVATAR_EMOJIS, SECTIONS, TOTAL_STICKERS } from '../lib/constants'
import { shareText, Modal } from '../components/ui'
import LocationPicker from '../components/LocationPicker'

export default function ProfilePage({ profile, counts, statusMap, trades }) {
  const { setProfile, signOut, user } = useAuth()
  const toast = useToast()
  const [name, setName] = useState(profile.name)
  const [emoji, setEmoji] = useState(profile.avatar_emoji)
  const [location, setLocation] = useState({ name: profile.city, lat: profile.lat, lng: profile.lng })
  const [radius, setRadius] = useState(profile.radius_km)
  const [saving, setSaving] = useState(false)
  const [fb, setFb] = useState('')
  const [fbEmail, setFbEmail] = useState('')
  const [fbState, setFbState] = useState('idle')
  const [showMap, setShowMap] = useState(false)

  const dirty =
    name !== profile.name || emoji !== profile.avatar_emoji ||
    location.name !== profile.city || radius !== profile.radius_km

  const save = async () => {
    if (!name.trim()) { toast.error('Name darf nicht leer sein.'); return }
    setSaving(true)
    const patch = { name: name.trim(), avatar_emoji: emoji, city: location.name, lat: location.lat, lng: location.lng, radius_km: radius }
    const { error } = await supabase.from('profiles').update(patch).eq('id', profile.id)
    if (error) toast.error('Speichern fehlgeschlagen.')
    else { setProfile(p => ({ ...p, ...patch })); toast.success('Profil gespeichert ✓') }
    setSaving(false)
  }

  const sendFeedback = async () => {
    if (!fb.trim()) return
    setFbState('sending')
    const { error } = await supabase.from('feedback').insert({ user_id: profile.id, message: fb.trim(), email: fbEmail.trim() || null })
    if (error) { toast.error('Feedback konnte nicht gesendet werden.'); setFbState('idle') }
    else { setFb(''); setFbEmail(''); setFbState('idle'); toast.success('Danke für dein Feedback! 🙏') }
  }

  const donut = [
    { name: 'Vorhanden', value: counts.have, color: '#003087' },
    { name: 'Doppelt', value: counts.double, color: '#ff8c00' },
    { name: 'Fehlend', value: counts.missing, color: '#ff4444' },
  ]

  // Fortschritt pro Bereich
  const groupBars = useMemo(() => {
    const areas = [
      { name: 'Intro', secs: SECTIONS.filter(s => s.id === 'intro') },
      { name: 'Amerika', secs: SECTIONS.filter(s => s.conf === 'america') },
      { name: 'Europa', secs: SECTIONS.filter(s => s.conf === 'europe') },
      { name: 'Afr/As', secs: SECTIONS.filter(s => s.conf === 'afrasia') },
      { name: 'Museum', secs: SECTIONS.filter(s => s.id === 'museum') },
      { name: 'Extra', secs: SECTIONS.filter(s => s.id === 'extra') },
    ]
    return areas.map(a => {
      let owned = 0, total = 0
      a.secs.forEach(sec => {
        for (let n = sec.from; n <= sec.to; n++) { total++; if (statusMap.has(n)) owned++ }
      })
      return { name: a.name, pct: total > 0 ? Math.round((owned / total) * 100) : 0 }
    })
  }, [statusMap])

  const completedTrades = (trades ?? []).filter(t => t.status === 'accepted').length

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-5 max-w-2xl">
      <header>
        <h1 className="font-display text-4xl text-gold">Profil</h1>
        <p className="text-sm text-white/45">{user?.email}</p>
      </header>

      {/* Statistiken */}
      <section className="bg-card border border-white/10 rounded-2xl p-5">
        <h2 className="font-display text-2xl mb-3">Statistiken</h2>
        <div className="grid grid-cols-3 gap-2 mb-4 text-center">
          <Kpi label="Doppelte" value={counts.double} color="text-double" />
          <Kpi label="Fehlende" value={counts.missing} color="text-missing" />
          <Kpi label="Tauschs" value={completedTrades} color="text-match" />
        </div>
        <div className="relative h-52">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={donut} dataKey="value" innerRadius="68%" outerRadius="92%" paddingAngle={2} strokeWidth={0}>
                {donut.map(d => <Cell key={d.name} fill={d.color} />)}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="font-display text-4xl text-gold">{counts.owned} / {TOTAL_STICKERS}</span>
            <span className="text-[11px] text-white/45">gesammelt</span>
          </div>
        </div>
        <div className="flex justify-center gap-4 text-[11px] text-white/55 mb-5">
          {donut.map(d => (
            <span key={d.name} className="flex items-center gap-1.5">
              <i className="w-2.5 h-2.5 rounded-sm inline-block" style={{ background: d.color }} /> {d.name}
            </span>
          ))}
        </div>
        <h3 className="text-sm font-medium text-white/75 mb-2">Vollständigkeit pro Gruppe</h3>
        <div className="h-40">
          <ResponsiveContainer>
            <BarChart data={groupBars} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
              <XAxis dataKey="name" stroke="#ffffff55" fontSize={10} tickLine={false} axisLine={false} />
              <YAxis domain={[0, 100]} stroke="#ffffff35" fontSize={10} tickLine={false} axisLine={false} unit="%" />
              <Tooltip
                cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                contentStyle={{ background: '#1c2138', border: '1px solid rgba(255,255,255,0.15)', borderRadius: 10, fontSize: 12 }}
                formatter={v => [`${v} %`, 'komplett']}
              />
              <Bar dataKey="pct" fill="#FFD700" radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Einstellungen */}
      <section className="bg-card border border-white/10 rounded-2xl p-5 flex flex-col gap-4">
        <h2 className="font-display text-2xl">Einstellungen</h2>
        <div>
          <label htmlFor="pf-name" className="text-sm font-medium text-white/80">Name</label>
          <input id="pf-name" value={name} onChange={e => setName(e.target.value)} maxLength={40}
            className="mt-1.5 w-full bg-bg border border-white/15 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-gold" />
        </div>
        <div>
          <p className="text-sm font-medium text-white/80 mb-1.5">Avatar</p>
          <div className="grid grid-cols-8 gap-1.5" role="radiogroup">
            {AVATAR_EMOJIS.map(e => (
              <button key={e} role="radio" aria-checked={emoji === e} onClick={() => setEmoji(e)}
                className={`aspect-square rounded-lg text-lg flex items-center justify-center ${emoji === e ? 'bg-gold/20 ring-2 ring-gold' : 'bg-bg hover:bg-card2'}`}>
                {e}
              </button>
            ))}
          </div>
        </div>

        {/* Standort */}
        <div>
          <p className="text-sm font-medium text-white/80 mb-1.5">Standort</p>
          <button
            onClick={() => setShowMap(true)}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl border bg-bg border-white/15 text-sm hover:border-white/40 text-left"
          >
            <MapPin size={14} className="text-gold shrink-0" />
            <span className="flex-1 truncate text-white/80">{location.name}</span>
            <span className="text-white/40 text-xs">ändern</span>
          </button>
        </div>

        <div>
          <label htmlFor="pf-radius" className="text-sm font-medium text-white/80 flex justify-between">
            <span>Radius</span><span className="font-mono text-gold">{radius} km</span>
          </label>
          <input id="pf-radius" type="range" min={1} max={200} value={radius}
            onChange={e => setRadius(+e.target.value)} className="mt-2 w-full" />
        </div>
        <button onClick={save} disabled={!dirty || saving}
          className="bg-gold text-bg font-bold rounded-xl py-2.5 text-sm hover:brightness-110 disabled:opacity-35 flex items-center justify-center gap-2">
          {saving && <Loader2 size={15} className="animate-spin" />} Änderungen speichern
        </button>
      </section>

      {/* Feedback */}
      <section className="bg-card border border-gold/25 rounded-2xl p-5 flex flex-col gap-3">
        <h2 className="font-display text-2xl">Feedback 🧪</h2>
        <p className="text-xs text-white/50 -mt-2">Was nervt? Was fehlt? Jede Zeile hilft.</p>
        <textarea value={fb} onChange={e => setFb(e.target.value)} rows={3} maxLength={2000}
          placeholder="Dein Feedback…"
          className="w-full bg-bg border border-white/15 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-gold resize-none placeholder:text-white/30" />
        <input value={fbEmail} onChange={e => setFbEmail(e.target.value)} type="email"
          placeholder="E-Mail für Rückfragen (optional)"
          className="w-full bg-bg border border-white/15 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-gold placeholder:text-white/30" />
        <button onClick={sendFeedback} disabled={!fb.trim() || fbState === 'sending'}
          className="bg-card2 border border-gold/40 text-gold font-bold rounded-xl py-2.5 text-sm hover:bg-gold/10 disabled:opacity-40 flex items-center justify-center gap-2">
          {fbState === 'sending' ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />} Feedback senden
        </button>
      </section>

      <div className="flex flex-col gap-2">
        <button onClick={() => shareText(`⚽ Sammle WM-2026-Sticker? Tauschen wir auf StickerSwap 26: ${window.location.origin}`, toast)}
          className="flex items-center justify-center gap-2 bg-card border border-white/15 rounded-xl py-3 text-sm font-medium hover:border-gold/50">
          <Share2 size={15} /> App-Link teilen
        </button>
        <button onClick={signOut}
          className="flex items-center justify-center gap-2 bg-card border border-white/15 rounded-xl py-3 text-sm font-medium text-white/65 hover:border-missing/50 hover:text-missing">
          <LogOut size={15} /> Abmelden
        </button>
      </div>
      <p className="text-center text-[10px] text-white/25 pb-2">
        StickerSwap 26 · inoffizielles Fan-Projekt
      </p>

      {/* Karten-Modal */}
      <Modal open={showMap} onClose={() => setShowMap(false)} title="Standort ändern">
        <div className="h-[60vh] flex flex-col">
          <LocationPicker
            initial={location}
            onSelect={loc => { setLocation(loc); setShowMap(false) }}
            onClose={() => setShowMap(false)}
          />
        </div>
      </Modal>
    </div>
  )
}

function Kpi({ label, value, color }) {
  return (
    <div className="bg-bg/60 rounded-xl py-2.5">
      <div className={`font-display text-2xl ${color}`}>{value}</div>
      <div className="text-[10px] text-white/45">{label}</div>
    </div>
  )
}
