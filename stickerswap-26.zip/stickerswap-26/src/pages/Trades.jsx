import { useState } from 'react'
import { Check, X, Loader2, Clock } from 'lucide-react'
import { Modal, EmptyState, SkeletonList, StickerChips, shareText } from '../components/ui'
import { MESSAGE_TEMPLATES } from '../lib/constants'
import { useToast } from '../hooks/useToast'

export default function TradesPage({ matches, trades, accept, decline, request, incomingPending, userId, reloadMatches }) {
  const toast = useToast()
  const [view, setView] = useState('matches') // matches | inbox
  const [target, setTarget] = useState(null) // Match für Modal
  const [message, setMessage] = useState(MESSAGE_TEMPLATES[0])
  const [sending, setSending] = useState(false)
  const [busy, setBusy] = useState(null)

  const send = async () => {
    setSending(true)
    const ok = await request({
      partnerId: target.user_id,
      give: target.i_give,
      get: target.i_get,
      message,
    })
    setSending(false)
    if (ok) {
      setTarget(null)
      setMessage(MESSAGE_TEMPLATES[0])
    }
  }

  const onAccept = async (id) => {
    setBusy(id)
    await accept(id)
    await reloadMatches()
    setBusy(null)
  }
  const onDecline = async (id) => {
    setBusy(id)
    await decline(id)
    setBusy(null)
  }

  const pendingOut = (trades ?? []).filter((t) => t.requester_id === userId && t.status === 'pending')
  const history = (trades ?? []).filter((t) => t.status !== 'pending')
  const alreadyRequested = new Set(pendingOut.map((t) => t.partner_id))

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-4 max-w-2xl">
      <header>
        <h1 className="font-display text-4xl text-gold">Tauschen</h1>
      </header>

      <div className="flex gap-2">
        <TabBtn active={view === 'matches'} onClick={() => setView('matches')}>
          Matches {matches ? `(${matches.length})` : ''}
        </TabBtn>
        <TabBtn active={view === 'inbox'} onClick={() => setView('inbox')} badge={incomingPending.length}>
          Posteingang
        </TabBtn>
      </div>

      {view === 'matches' && (
        <>
          {matches === null ? (
            <SkeletonList rows={3} />
          ) : matches.length === 0 ? (
            <div className="bg-card border border-white/10 rounded-2xl">
              <EmptyState
                emoji="🤝"
                title="Noch keine Matches"
                text="Markiere deine Doppelten im Album und lade Freunde ein – Matches entstehen, sobald sich Angebot und Bedarf treffen."
                action={
                  <button
                    onClick={() => shareText(`⚽ Sammle WM-2026-Sticker? Tauschen wir auf StickerSwap 26: ${window.location.origin}`, toast)}
                    className="mt-2 bg-gold text-bg font-bold rounded-xl px-5 py-2 text-xs hover:brightness-110"
                  >
                    App-Link teilen
                  </button>
                }
              />
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {matches.map((m, i) => {
                const maxScore = matches[0]?.score || 1
                return (
                  <div
                    key={m.user_id}
                    style={{ animationDelay: `${i * 60}ms` }}
                    className="animate-card bg-card border border-white/10 rounded-2xl p-4 flex flex-col gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{m.avatar_emoji}</span>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-sm truncate">{m.name}</p>
                        <p className="text-xs text-white/45">{m.city} · {m.distance_km} km</p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="font-display text-2xl text-match">{m.score}×</span>
                        <div className="w-16 h-1.5 bg-card2 rounded-full mt-1 overflow-hidden">
                          <div className="h-full bg-match rounded-full" style={{ width: `${(m.score / maxScore) * 100}%` }} />
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-white/65 flex flex-col gap-1.5 bg-bg/50 rounded-xl p-2.5">
                      <span>Du gibst: <StickerChips nums={m.i_give} color="double" /></span>
                      <span>Du bekommst: <StickerChips nums={m.i_get} color="match" /></span>
                    </div>
                    <button
                      onClick={() => setTarget(m)}
                      disabled={alreadyRequested.has(m.user_id)}
                      className="bg-gold text-bg font-bold rounded-xl py-2.5 text-sm hover:brightness-110 disabled:opacity-40 disabled:cursor-default focus-visible:outline focus-visible:outline-2 focus-visible:outline-white"
                    >
                      {alreadyRequested.has(m.user_id) ? 'Anfrage gesendet ✓' : 'Tausch anfragen'}
                    </button>
                  </div>
                )
              })}
            </div>
          )}
        </>
      )}

      {view === 'inbox' && (
        <>
          {trades === null ? (
            <SkeletonList rows={3} />
          ) : (
            <>
              {/* Eingehende offene Anfragen */}
              <h2 className="font-display text-xl text-white/85 -mb-1">Offene Anfragen</h2>
              {incomingPending.length === 0 && pendingOut.length === 0 ? (
                <div className="bg-card border border-white/10 rounded-2xl">
                  <EmptyState emoji="📭" title="Posteingang leer" text="Neue Anfragen erscheinen hier sofort – ganz ohne Neuladen." />
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {incomingPending.map((t) => (
                    <div key={t.id} className="animate-card bg-card border border-gold/30 rounded-2xl p-4 flex flex-col gap-2.5">
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">{t.requester.avatar_emoji}</span>
                        <div className="flex-1">
                          <p className="font-bold text-sm">{t.requester.name}</p>
                          <p className="text-[11px] text-white/40">{t.requester.city} · {timeAgo(t.created_at)}</p>
                        </div>
                      </div>
                      {t.message && <p className="text-xs bg-bg/60 rounded-lg px-3 py-2 text-white/75">„{t.message}"</p>}
                      <div className="text-xs text-white/65 flex flex-col gap-1.5">
                        <span>Du bekommst: <StickerChips nums={t.give_stickers} color="match" /></span>
                        <span>Du gibst: <StickerChips nums={t.get_stickers} color="double" /></span>
                      </div>
                      <div className="flex gap-2 mt-1">
                        <button
                          onClick={() => onAccept(t.id)}
                          disabled={busy === t.id}
                          className="flex-1 bg-match/90 text-bg font-bold rounded-xl py-2.5 text-sm flex items-center justify-center gap-1.5 hover:brightness-110 disabled:opacity-60"
                        >
                          {busy === t.id ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />} Annehmen
                        </button>
                        <button
                          onClick={() => onDecline(t.id)}
                          disabled={busy === t.id}
                          className="flex-1 bg-card2 border border-white/15 font-medium rounded-xl py-2.5 text-sm flex items-center justify-center gap-1.5 hover:border-missing/60 disabled:opacity-60"
                        >
                          <X size={15} /> Ablehnen
                        </button>
                      </div>
                    </div>
                  ))}
                  {pendingOut.map((t) => (
                    <div key={t.id} className="bg-card border border-white/10 rounded-2xl p-4 flex items-center gap-3 opacity-80">
                      <Clock size={18} className="text-white/35 shrink-0" />
                      <div className="flex-1 text-xs text-white/55">
                        Anfrage an <span className="text-white font-medium">{t.partner.name}</span> · wartet auf Antwort
                      </div>
                      <span className="text-[10px] text-white/30">{timeAgo(t.created_at)}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Historie */}
              <h2 className="font-display text-xl text-white/85 mt-2 -mb-1">Historie</h2>
              {history.length === 0 ? (
                <p className="text-xs text-white/35 px-1">Abgeschlossene Tauschs erscheinen hier.</p>
              ) : (
                <div className="flex flex-col gap-2">
                  {history.map((t) => {
                    const other = t.requester_id === userId ? t.partner : t.requester
                    return (
                      <div key={t.id} className="bg-card border border-white/10 rounded-xl px-4 py-3 flex items-center gap-3 text-xs">
                        <span className="text-xl">{other.avatar_emoji}</span>
                        <div className="flex-1 min-w-0">
                          <span className="font-medium text-white/85">{other.name}</span>
                          <span className="text-white/35"> · {new Date(t.updated_at).toLocaleString('de-DE', { dateStyle: 'short', timeStyle: 'short' })}</span>
                        </div>
                        <span className={`font-bold shrink-0 ${t.status === 'accepted' ? 'text-match' : 'text-white/35'}`}>
                          {t.status === 'accepted' ? '✓ Getauscht' : '✗ Abgelehnt'}
                        </span>
                      </div>
                    )
                  })}
                </div>
              )}
            </>
          )}
        </>
      )}

      {/* Anfrage-Modal */}
      <Modal open={!!target} onClose={() => setTarget(null)} title={`Tausch mit ${target?.name ?? ''}`}>
        {target && (
          <div className="flex flex-col gap-4">
            <div className="text-xs text-white/65 flex flex-col gap-1.5 bg-bg/60 rounded-xl p-3">
              <span>Du gibst: <StickerChips nums={target.i_give} color="double" max={12} /></span>
              <span>Du bekommst: <StickerChips nums={target.i_get} color="match" max={12} /></span>
            </div>
            <div>
              <p className="text-sm font-medium mb-2">Nachricht</p>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {MESSAGE_TEMPLATES.map((t) => (
                  <button
                    key={t}
                    onClick={() => setMessage(t)}
                    className={`text-[11px] px-2.5 py-1 rounded-full border ${
                      message === t ? 'bg-gold text-bg border-gold font-bold' : 'bg-card2 border-white/15 text-white/65'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                maxLength={300}
                rows={2}
                aria-label="Nachricht an Tauschpartner"
                className="w-full bg-bg border border-white/15 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-gold resize-none"
              />
            </div>
            <button
              onClick={send}
              disabled={sending}
              className="bg-gold text-bg font-bold rounded-xl py-3 text-sm hover:brightness-110 disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {sending && <Loader2 size={15} className="animate-spin" />} Anfrage senden 🤝
            </button>
          </div>
        )}
      </Modal>
    </div>
  )
}

function TabBtn({ active, onClick, children, badge = 0 }) {
  return (
    <button
      onClick={onClick}
      className={`relative px-4 py-2 rounded-xl text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-gold ${
        active ? 'bg-gold text-bg font-bold' : 'bg-card text-white/60 border border-white/15'
      }`}
    >
      {children}
      {badge > 0 && (
        <span className="absolute -top-1.5 -right-1.5 bg-missing text-white text-[10px] font-bold rounded-full min-w-5 h-5 px-1 flex items-center justify-center">
          {badge}
        </span>
      )}
    </button>
  )
}

function timeAgo(iso) {
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000)
  if (s < 60) return 'gerade eben'
  if (s < 3600) return `vor ${Math.floor(s / 60)} Min.`
  if (s < 86400) return `vor ${Math.floor(s / 3600)} Std.`
  return `vor ${Math.floor(s / 86400)} Tagen`
}
