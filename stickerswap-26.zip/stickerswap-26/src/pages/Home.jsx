import { Share2, ArrowRight } from 'lucide-react'
import { ProgressRing, Skeleton, EmptyState, StickerChips, shareText } from '../components/ui'
import { useToast } from '../hooks/useToast'
import { TOTAL_STICKERS } from '../lib/constants'

export default function HomePage({ profile, counts, stickersLoading, matches, incomingPending, setTab, statusMap }) {
  const toast = useToast()

  const doubles = [...statusMap.entries()].filter(([, s]) => s === 'double').map(([n]) => n).sort((a, b) => a - b)
  const missingSample = []
  for (let n = 1; n <= TOTAL_STICKERS && missingSample.length < 10; n++) {
    if (!statusMap.has(n)) missingSample.push(n)
  }

  const share = () =>
    shareText(
      `⚽ StickerSwap 26 – ich suche ${missingSample.slice(0, 6).map((n) => `#${n}`).join(', ')}${counts.missing > 6 ? ' …' : ''} und tausche gegen ${doubles.slice(0, 6).map((n) => `#${n}`).join(', ')}${doubles.length > 6 ? ' …' : ''}. Tauschen wir? ${window.location.origin}`,
      toast,
    )

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-5 max-w-2xl">
      <header className="flex items-center justify-between">
        <div>
          <p className="text-sm text-white/45">Hey {profile.name.replace(' 🤖', '')} 👋</p>
          <h1 className="font-display text-4xl text-gold">Dein Album</h1>
        </div>
        <span className="text-4xl" aria-hidden="true">{profile.avatar_emoji}</span>
      </header>

      {/* Fortschritt */}
      <section className="bg-card border border-white/10 rounded-2xl p-5 flex items-center gap-5">
        {stickersLoading ? (
          <Skeleton className="w-[150px] h-[150px] rounded-full" />
        ) : (
          <ProgressRing value={counts.owned} max={TOTAL_STICKERS} label="gesammelt" />
        )}
        <div className="flex-1 grid gap-2">
          <Stat color="text-double" label="Doppelte" value={stickersLoading ? '–' : counts.double} />
          <Stat color="text-missing" label="Fehlende" value={stickersLoading ? '–' : counts.missing} />
          <button
            onClick={share}
            className="mt-1 flex items-center justify-center gap-2 bg-card2 border border-white/10 rounded-xl py-2 text-xs font-medium hover:border-gold/50 focus-visible:outline focus-visible:outline-gold"
          >
            <Share2 size={14} /> Tauschliste teilen
          </button>
        </div>
      </section>

      {/* Offene Anfragen */}
      {incomingPending.length > 0 && (
        <button
          onClick={() => setTab('trades')}
          className="animate-card bg-gold/10 border border-gold/40 rounded-2xl p-4 flex items-center gap-3 text-left hover:bg-gold/15 focus-visible:outline focus-visible:outline-gold"
        >
          <span className="text-2xl">📬</span>
          <div className="flex-1">
            <p className="font-bold text-sm text-gold">
              {incomingPending.length} offene Tauschanfrage{incomingPending.length > 1 ? 'n' : ''}
            </p>
            <p className="text-xs text-white/55">Jetzt ansehen und entscheiden</p>
          </div>
          <ArrowRight size={18} className="text-gold" />
        </button>
      )}

      {/* Neue Matches */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-2xl">Deine Matches</h2>
          {matches?.length > 0 && (
            <button onClick={() => setTab('trades')} className="text-xs text-gold hover:underline">
              Alle ansehen
            </button>
          )}
        </div>
        {matches === null ? (
          <div className="flex flex-col gap-3">
            <Skeleton className="h-20" />
            <Skeleton className="h-20" />
          </div>
        ) : matches.length === 0 ? (
          <div className="bg-card border border-white/10 rounded-2xl">
            <EmptyState
              emoji="🔍"
              title="Noch keine Matches"
              text="Lade Freunde ein oder vergrößere deinen Radius – je mehr Sammler, desto mehr Tauschpartner."
              action={
                <button
                  onClick={() => shareText(`⚽ Sammle WM-2026-Sticker? Tauschen wir auf StickerSwap 26: ${window.location.origin}`, toast)}
                  className="mt-2 bg-gold text-bg font-bold rounded-xl px-5 py-2 text-xs hover:brightness-110"
                >
                  App-Link teilen
                </button>
              }
            />
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {matches.slice(0, 3).map((m, i) => (
              <button
                key={m.user_id}
                onClick={() => setTab('trades')}
                style={{ animationDelay: `${i * 70}ms` }}
                className="animate-card bg-card border border-white/10 rounded-2xl p-4 flex items-center gap-3 text-left hover:border-match/50 focus-visible:outline focus-visible:outline-gold"
              >
                <span className="text-3xl">{m.avatar_emoji}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm truncate">
                    {m.name} <span className="text-white/40 font-normal">· {m.city}, {m.distance_km} km</span>
                  </p>
                  <p className="text-xs text-white/55 mt-0.5">
                    Du bekommst <StickerChips nums={m.i_get} color="match" max={3} />
                  </p>
                </div>
                <span className="font-display text-2xl text-match shrink-0">{m.score}×</span>
              </button>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}

function Stat({ label, value, color }) {
  return (
    <div className="flex items-baseline justify-between bg-bg/60 rounded-xl px-3 py-2">
      <span className="text-xs text-white/55">{label}</span>
      <span className={`font-display text-2xl ${color}`}>{value}</span>
    </div>
  )
}
