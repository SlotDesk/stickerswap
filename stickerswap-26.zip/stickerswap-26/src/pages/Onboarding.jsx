import { useState } from 'react'
import { Loader2 } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { useToast } from '../hooks/useToast'
import { AVATAR_EMOJIS, ALBUM_STICKERS } from '../lib/constants'
import { Modal } from '../components/ui'
import LocationPicker from '../components/LocationPicker'

export default function Onboarding() {
  const { user, refreshProfile } = useAuth()
  const toast = useToast()
  const [step, setStep] = useState(0)
  const [name, setName] = useState('')
  const [emoji, setEmoji] = useState('⚽')
  const [location, setLocation] = useState(null)
  const [radius, setRadius] = useState(25)
  const [startCount, setStartCount] = useState(80)
  const [saving, setSaving] = useState(false)
  const [showMap, setShowMap] = useState(false)

  const finish = async () => {
    if (!location) { toast.error('Bitte wähle einen Ort.'); return }
    setSaving(true)
    const { error } = await supabase.from('profiles').insert({
      id: user.id,
      name: name.trim(),
      avatar_emoji: emoji,
      city: location.name,
      lat: location.lat,
      lng: location.lng,
      radius_km: radius,
    })
    if (error) {
      toast.error('Profil konnte nicht gespeichert werden: ' + error.message)
      setSaving(false)
      return
    }

    if (startCount > 0) {
      const all = Array.from({ length: ALBUM_STICKERS }, (_, i) => i + 1)
      for (let i = all.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1))
        ;[all[i], all[j]] = [all[j], all[i]]
      }
      const picked = all.slice(0, startCount)
      const rows = picked.map((no, idx) => ({
        user_id: user.id,
        sticker_no: no,
        status: idx < Math.round(startCount * 0.12) ? 'double' : 'have',
      }))
      const { error: e2 } = await supabase.from('sticker_status').insert(rows)
      if (e2) toast.error('Schnellstart-Inventar nicht gespeichert – bitte im Album nachpflegen.')
    }

    await refreshProfile()
    setSaving(false)
  }

  return (
    <div className="min-h-dvh flex items-center justify-center p-6 relative z-10">
      <div className="w-full max-w-md">
        {/* Fortschritt */}
        <div className="flex justify-center gap-2 mb-6" aria-hidden="true">
          {[0, 1, 2].map(i => (
            <div key={i} className={`h-1.5 rounded-full transition-all ${i === step ? 'w-8 bg-gold' : 'w-3 bg-white/15'}`} />
          ))}
        </div>

        <div className="bg-card border border-white/10 rounded-2xl p-6 animate-card" key={step}>
          {/* Step 0 – Willkommen */}
          {step === 0 && (
            <div className="text-center py-6">
              <div className="text-7xl animate-bounce inline-block">🏆</div>
              <h1 className="font-display text-4xl text-gold mt-4">StickerSwap 26</h1>
              <p className="text-sm text-white/55 mt-3 max-w-xs mx-auto">
                1000 Sticker, 48 Teams, echte Tauschpartner in deiner Nähe.
              </p>
              <button
                onClick={() => setStep(1)}
                className="mt-6 bg-gold text-bg font-bold rounded-xl px-8 py-3 text-sm hover:brightness-110"
              >
                Jetzt starten
              </button>
            </div>
          )}

          {/* Step 1 – Profil + Standort */}
          {step === 1 && (
            <div className="flex flex-col gap-4">
              <h2 className="font-display text-3xl">Dein Profil</h2>

              <div>
                <label htmlFor="ob-name" className="text-sm font-medium text-white/80">Name</label>
                <input
                  id="ob-name"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  maxLength={40}
                  placeholder="z. B. Alex"
                  className="mt-1.5 w-full bg-bg border border-white/15 rounded-xl px-3 py-3 text-sm outline-none focus:border-gold placeholder:text-white/30"
                />
              </div>

              <div>
                <p className="text-sm font-medium text-white/80 mb-1.5">Avatar</p>
                <div className="grid grid-cols-8 gap-1.5" role="radiogroup">
                  {AVATAR_EMOJIS.map(e => (
                    <button
                      key={e}
                      role="radio"
                      aria-checked={emoji === e}
                      onClick={() => setEmoji(e)}
                      className={`aspect-square rounded-lg text-xl flex items-center justify-center transition-all ${
                        emoji === e ? 'bg-gold/20 ring-2 ring-gold scale-110' : 'bg-bg hover:bg-card2'
                      }`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              {/* Standort */}
              <div>
                <p className="text-sm font-medium text-white/80 mb-1.5">Dein Standort</p>
                <button
                  onClick={() => setShowMap(true)}
                  className={`w-full flex items-center gap-2 px-3 py-3 rounded-xl border text-sm text-left transition-colors ${
                    location
                      ? 'bg-gold/10 border-gold/40 text-gold'
                      : 'bg-bg border-white/15 text-white/50 hover:border-white/40'
                  }`}
                >
                  <span className="text-lg">📍</span>
                  <span className="flex-1 truncate">{location ? location.name : 'Ort auf Karte wählen…'}</span>
                  <span className="text-white/40 text-xs shrink-0">→</span>
                </button>
              </div>

              <div>
                <label htmlFor="ob-radius" className="text-sm font-medium text-white/80 flex justify-between">
                  <span>Tausch-Radius</span>
                  <span className="font-mono text-gold">{radius} km</span>
                </label>
                <input
                  id="ob-radius"
                  type="range" min={1} max={200} value={radius}
                  onChange={e => setRadius(+e.target.value)}
                  className="mt-2 w-full"
                />
              </div>

              <button
                onClick={() => setStep(2)}
                disabled={!name.trim() || !location}
                className="mt-2 w-full bg-gold text-bg font-bold rounded-xl py-3 text-sm hover:brightness-110 disabled:opacity-40"
              >
                Weiter
              </button>
            </div>
          )}

          {/* Step 2 – Schnellstart */}
          {step === 2 && (
            <div>
              <h2 className="font-display text-3xl mb-1">Schnellstart</h2>
              <p className="text-sm text-white/55 mb-6">
                Wie viele der {ALBUM_STICKERS} Album-Sticker hast du ungefähr schon? Wir füllen dein Album zufällig vor.
              </p>
              <div className="text-center mb-2">
                <span className="font-display text-6xl text-gold">{startCount}</span>
                <span className="text-white/40 text-sm"> / {ALBUM_STICKERS}</span>
              </div>
              <input
                type="range" min={0} max={ALBUM_STICKERS} value={startCount}
                onChange={e => setStartCount(+e.target.value)}
                aria-label="Anzahl vorhandener Sticker"
                className="w-full"
              />
              <button
                onClick={finish}
                disabled={saving}
                className="mt-8 w-full bg-gold text-bg font-bold rounded-xl py-3 text-sm hover:brightness-110 disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {saving && <Loader2 size={16} className="animate-spin" />}
                Album anlegen & loslegen
              </button>
              <button onClick={() => setStep(1)} className="mt-3 w-full text-xs text-white/40 hover:text-white/70">
                Zurück
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Karten-Modal */}
      <Modal open={showMap} onClose={() => setShowMap(false)} title="Standort wählen">
        <div className="h-[60vh] flex flex-col">
          <LocationPicker
            initial={location}
            onSelect={loc => { setLocation(loc); setShowMap(false) }}
            onClose={() => setShowMap(false)}
          />
        </div>
      </Modal>
    </div>
  )
}
