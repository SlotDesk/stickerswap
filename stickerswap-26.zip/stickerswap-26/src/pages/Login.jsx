import { useState } from 'react'
import { Mail, Loader2, Share, MoreVertical, Smartphone } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useToast } from '../hooks/useToast'

export default function Login() {
  const toast = useToast()
  const [email, setEmail] = useState('')
  const [state, setState] = useState('idle')
  const [platform, setPlatform] = useState(() =>
    /iphone|ipad|ipod/i.test(navigator.userAgent) ? 'ios' : 'android'
  )

  const send = async () => {
    const clean = email.trim().toLowerCase()
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(clean)) {
      toast.error('Bitte gib eine gültige E-Mail-Adresse ein.')
      return
    }
    setState('sending')
    const { error } = await supabase.auth.signInWithOtp({
      email: clean,
      options: { emailRedirectTo: window.location.origin },
    })
    if (error) {
      toast.error('Link konnte nicht gesendet werden: ' + error.message)
      setState('idle')
    } else {
      setState('sent')
    }
  }

  return (
    <div className="min-h-dvh flex flex-col items-center justify-center p-5 gap-5 relative z-10">
      <div className="w-full max-w-sm flex flex-col gap-4">

        {/* Hero */}
        <div className="text-center mb-2">
          <div className="text-6xl mb-3">⚽</div>
          <h1 className="font-display text-5xl text-gold">StickerSwap 26</h1>
          <p className="text-white/50 mt-2 text-sm">
            1000 Sticker · 48 Teams · Tauschpartner in deiner Nähe
          </p>
        </div>

        {/* Login */}
        <div className="bg-card border border-white/10 rounded-2xl p-5">
          {state === 'sent' ? (
            <div className="text-center py-4">
              <div className="text-4xl mb-2">📬</div>
              <h2 className="font-display text-2xl mb-1">Check dein Postfach</h2>
              <p className="text-sm text-white/60">
                Login-Link an <span className="text-gold">{email}</span> gesendet.
                Einfach anklicken – fertig.
              </p>
              <button onClick={() => setState('idle')} className="mt-4 text-xs text-white/40 underline hover:text-white/70">
                Andere Adresse verwenden
              </button>
            </div>
          ) : (
            <>
              <label htmlFor="email" className="text-sm font-medium text-white/80">E-Mail-Adresse</label>
              <div className="mt-2 flex items-center gap-2 bg-bg border border-white/15 rounded-xl px-3 focus-within:border-gold">
                <Mail size={16} className="text-white/40 shrink-0" />
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  placeholder="du@beispiel.de"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && send()}
                  className="w-full bg-transparent py-3 text-sm outline-none placeholder:text-white/30"
                />
              </div>
              <button
                onClick={send}
                disabled={state === 'sending'}
                className="mt-4 w-full bg-gold text-bg font-bold rounded-xl py-3 text-sm hover:brightness-110 disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {state === 'sending' && <Loader2 size={16} className="animate-spin" />}
                Magic Link senden
              </button>
              <p className="text-[11px] text-white/35 mt-3 text-center">
                Kein Passwort nötig.
              </p>
            </>
          )}
        </div>

        {/* Homescreen-Anleitung */}
        <div className="bg-card border border-white/10 rounded-2xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 pt-4 pb-2">
            <Smartphone size={15} className="text-gold" />
            <p className="text-sm font-medium">Zum Homescreen hinzufügen</p>
          </div>

          {/* iOS / Android Tabs */}
          <div className="flex border-b border-white/10 px-4">
            {['ios', 'android'].map(p => (
              <button
                key={p}
                onClick={() => setPlatform(p)}
                className={`pb-2 pt-1 mr-4 text-xs font-medium border-b-2 transition-colors ${
                  platform === p ? 'border-gold text-gold' : 'border-transparent text-white/40'
                }`}
              >
                {p === 'ios' ? '🍎 iPhone / iPad' : '🤖 Android'}
              </button>
            ))}
          </div>

          <div className="px-4 py-3 flex flex-col gap-2">
            {platform === 'ios' ? (
              <>
                <InstallStep n={1} icon={<Share size={13} />}>
                  Tippe auf <Chip>Teilen</Chip> unten in der Safari-Leiste
                </InstallStep>
                <InstallStep n={2} icon="📜">
                  Scrolle im Menü nach unten zu <Chip>Zum Home-Bildschirm</Chip>
                </InstallStep>
                <InstallStep n={3} icon="✅">
                  Tippe auf <Chip>Hinzufügen</Chip> — fertig!
                </InstallStep>
                <p className="text-[10px] text-white/30 mt-1">
                  Nur in Safari verfügbar, nicht in Chrome oder Firefox auf iOS.
                </p>
              </>
            ) : (
              <>
                <InstallStep n={1} icon={<MoreVertical size={13} />}>
                  Tippe auf <Chip>⋮ Menü</Chip> oben rechts im Chrome-Browser
                </InstallStep>
                <InstallStep n={2} icon="📲">
                  Wähle <Chip>App installieren</Chip> oder <Chip>Zum Startbildschirm</Chip>
                </InstallStep>
                <InstallStep n={3} icon="✅">
                  Bestätige mit <Chip>Installieren</Chip> — fertig!
                </InstallStep>
                <p className="text-[10px] text-white/30 mt-1">
                  Funktioniert in Chrome, Edge und Samsung Internet.
                </p>
              </>
            )}
          </div>
        </div>

        <p className="text-center text-[10px] text-white/20">
          Inoffizielles Fan-Projekt · nicht mit Verbänden verbunden
        </p>
      </div>
    </div>
  )
}

function InstallStep({ n, icon, children }) {
  return (
    <div className="flex items-start gap-2.5 text-xs text-white/65">
      <span className="w-5 h-5 rounded-full bg-gold/20 text-gold text-[9px] font-bold flex items-center justify-center shrink-0 mt-0.5">
        {n}
      </span>
      <span className="flex items-center gap-1 flex-wrap leading-5">
        {typeof icon === 'string' ? icon : <span className="text-gold">{icon}</span>}
        {children}
      </span>
    </div>
  )
}

function Chip({ children }) {
  return (
    <span className="inline-block bg-white/10 px-1.5 py-0.5 rounded text-white/85 font-medium mx-0.5">
      {children}
    </span>
  )
}
