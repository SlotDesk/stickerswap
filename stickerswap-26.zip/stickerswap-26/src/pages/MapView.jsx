import { useEffect, useRef, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { useToast } from '../hooks/useToast'
import { Skeleton, StickerChips } from '../components/ui'

/**
 * Echte Weltkarte (Leaflet) mit eigenem Standort, Radius-Kreis (exakt in km),
 * Match-Markern (grün) und anderen Sammlern (grau).
 */
export default function MapPage({ profile, matches }) {
  const { setProfile } = useAuth()
  const toast = useToast()
  const mapRef = useRef(null)
  const leafletMap = useRef(null)
  const radiusCircle = useRef(null)
  const markersLayer = useRef(null)
  const [radius, setRadius] = useState(profile.radius_km)
  const [leafletReady, setLeafletReady] = useState(!!window.L)
  const [allProfiles, setAllProfiles] = useState(null)
  const [selected, setSelected] = useState(null)

  // Leaflet laden
  useEffect(() => {
    if (window.L) { setLeafletReady(true); return }
    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css'
    document.head.appendChild(link)
    const script = document.createElement('script')
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js'
    script.onload = () => setLeafletReady(true)
    document.head.appendChild(script)
  }, [])

  // Profile laden
  useEffect(() => {
    let active = true
    supabase
      .from('profiles')
      .select('id,name,avatar_emoji,city,lat,lng')
      .neq('id', profile.id)
      .then(({ data, error }) => {
        if (!active) return
        if (error) toast.error('Sammler konnten nicht geladen werden.')
        setAllProfiles(data ?? [])
      })
    return () => { active = false }
  }, [profile.id]) // eslint-disable-line react-hooks/exhaustive-deps

  // Karte initialisieren
  useEffect(() => {
    if (!leafletReady || !mapRef.current || leafletMap.current) return
    const L = window.L

    const map = L.map(mapRef.current).setView([profile.lat, profile.lng], 8)
    leafletMap.current = map

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '© OpenStreetMap, © CARTO',
      maxZoom: 19,
    }).addTo(map)

    // Eigener Standort: goldener Punkt + Puls
    const meIcon = L.divIcon({
      className: '',
      html: `<div style="position:relative;width:18px;height:18px">
        <div style="position:absolute;inset:-6px;border-radius:50%;background:rgba(255,215,0,0.3);animation:lpulse 2s ease-out infinite"></div>
        <div style="position:absolute;inset:0;border-radius:50%;background:#FFD700;border:3px solid #0a0e1a"></div>
      </div>
      <style>@keyframes lpulse{0%{transform:scale(0.6);opacity:0.9}100%{transform:scale(2.2);opacity:0}}</style>`,
      iconSize: [18, 18],
      iconAnchor: [9, 9],
    })
    L.marker([profile.lat, profile.lng], { icon: meIcon, zIndexOffset: 1000 }).addTo(map)

    // Radius-Kreis (Meter = km * 1000, geografisch exakt)
    radiusCircle.current = L.circle([profile.lat, profile.lng], {
      radius: profile.radius_km * 1000,
      color: '#FFD700',
      weight: 1.5,
      dashArray: '6 5',
      fillColor: '#FFD700',
      fillOpacity: 0.06,
    }).addTo(map)

    markersLayer.current = L.layerGroup().addTo(map)

    return () => { map.remove(); leafletMap.current = null; radiusCircle.current = null; markersLayer.current = null }
  }, [leafletReady]) // eslint-disable-line react-hooks/exhaustive-deps

  // Marker zeichnen, sobald Profile + Matches da sind
  useEffect(() => {
    if (!leafletMap.current || !markersLayer.current || allProfiles === null) return
    const L = window.L
    markersLayer.current.clearLayers()
    const matchMap = new Map((matches ?? []).map(m => [m.user_id, m]))

    allProfiles.forEach(p => {
      const m = matchMap.get(p.id)
      const isMatch = !!m
      const icon = L.divIcon({
        className: '',
        html: `<div style="width:14px;height:14px;border-radius:50%;background:${isMatch ? '#00ff88' : '#3a415e'};border:2px solid #0a0e1a;${isMatch ? 'box-shadow:0 0 8px rgba(0,255,136,0.6)' : ''}"></div>`,
        iconSize: [14, 14],
        iconAnchor: [7, 7],
      })
      const marker = L.marker([p.lat, p.lng], { icon }).addTo(markersLayer.current)
      marker.on('click', () => setSelected({ ...p, ...m, isMatch }))
    })
  }, [allProfiles, matches])

  // Radius-Kreis live updaten
  useEffect(() => {
    if (radiusCircle.current) radiusCircle.current.setRadius(radius * 1000)
  }, [radius])

  const saveRadius = async (km) => {
    const { error } = await supabase.from('profiles').update({ radius_km: km }).eq('id', profile.id)
    if (error) toast.error('Radius konnte nicht gespeichert werden.')
    else {
      setProfile(p => ({ ...p, radius_km: km }))
      toast.success(`Radius: ${km} km ✓`)
    }
  }

  return (
    <div className="p-4 lg:p-8 flex flex-col gap-4 max-w-3xl">
      <header>
        <h1 className="font-display text-4xl text-gold">Karte</h1>
        <p className="text-sm text-white/45">Sammler weltweit – grün heißt: Match!</p>
      </header>

      {/* Karte */}
      <div className="bg-card border border-white/10 rounded-2xl p-2 relative">
        {!leafletReady || allProfiles === null ? (
          <Skeleton className="w-full h-[380px] rounded-xl" />
        ) : (
          <div ref={mapRef} className="w-full h-[380px] lg:h-[460px] rounded-xl z-0" />
        )}
      </div>

      {/* Ausgewählter Sammler */}
      {selected && (
        <div className="animate-card bg-card2 border border-white/15 rounded-2xl p-4 flex items-start gap-3">
          <span className="text-3xl shrink-0">{selected.avatar_emoji}</span>
          <div className="flex-1 min-w-0 text-sm">
            <p className="font-bold">{selected.name}</p>
            <p className="text-xs text-white/50">
              {selected.city}{selected.distance_km != null && ` · ${selected.distance_km} km entfernt`}
            </p>
            {selected.isMatch ? (
              <div className="mt-2 flex flex-col gap-1 text-xs text-white/65">
                <span>Du bekommst: <StickerChips nums={selected.i_get} color="match" max={5} /></span>
                <span>Du gibst: <StickerChips nums={selected.i_give} color="double" max={5} /></span>
              </div>
            ) : (
              <p className="mt-1.5 text-xs text-white/40">
                Kein Tausch-Match (außerhalb des Radius oder keine passenden Sticker).
              </p>
            )}
          </div>
          <button onClick={() => setSelected(null)} className="text-white/40 hover:text-white shrink-0">✕</button>
        </div>
      )}

      {/* Radius */}
      <div className="bg-card border border-white/10 rounded-2xl p-4">
        <label htmlFor="map-radius" className="text-sm font-medium flex justify-between mb-2">
          <span>Tausch-Radius</span>
          <span className="font-mono text-gold">{radius} km</span>
        </label>
        <input
          id="map-radius"
          type="range" min={1} max={200} value={radius}
          onChange={e => setRadius(+e.target.value)}
          onMouseUp={e => saveRadius(+e.target.value)}
          onTouchEnd={() => saveRadius(radius)}
          onKeyUp={e => ['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key) && saveRadius(radius)}
          className="w-full"
        />
        <p className="text-[11px] text-white/35 mt-2">
          Der Kreis auf der Karte zeigt deinen Radius live. Matches gelten, wenn beide Radien sich erreichen.
        </p>
      </div>

      <div className="flex gap-4 text-xs text-white/55 px-1">
        <span className="flex items-center gap-1.5"><i className="w-2.5 h-2.5 rounded-full bg-gold inline-block" /> Du</span>
        <span className="flex items-center gap-1.5"><i className="w-2.5 h-2.5 rounded-full bg-match inline-block" /> Match</span>
        <span className="flex items-center gap-1.5"><i className="w-2.5 h-2.5 rounded-full bg-[#3a415e] inline-block" /> kein Match</span>
      </div>
    </div>
  )
}
