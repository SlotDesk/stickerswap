import { useMemo, useState } from 'react'
import { CheckCheck, ChevronDown, ChevronUp, Search, X } from 'lucide-react'
import {
  SECTIONS, TOTAL_STICKERS, isFoil, isExtra, isKeyPlayer,
  stickerCode, stickerLabel, searchStickers,
} from '../lib/constants'
import { Skeleton } from '../components/ui'

const STATUS_FILTERS = [
  { id: 'all', label: 'Alle' },
  { id: 'have', label: '✅ Vorhanden' },
  { id: 'double', label: '🔄 Doppelt' },
  { id: 'missing', label: '❌ Fehlend' },
]

const NAV = [
  { id: 'all', label: 'Alle', icon: '📖' },
  { id: 'intro', label: 'Intro', icon: '🏆' },
  { id: 'america', label: 'Amerika', icon: '🌎' },
  { id: 'europe', label: 'Europa', icon: '🌍' },
  { id: 'afrasia', label: 'Afrika/Asien', icon: '🌏' },
  { id: 'museum', label: 'Museum', icon: '🏛️' },
  { id: 'extra', label: 'Extra', icon: '💎' },
]

export default function AlbumPage({ statusMap, cycle, markSectionHave, counts, loading }) {
  const [nav, setNav] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [query, setQuery] = useState('')
  const [flipping, setFlipping] = useState(null)
  const [collapsed, setCollapsed] = useState(new Set())

  const searchHits = useMemo(() => searchStickers(query), [query])

  const toggleCollapse = (id) =>
    setCollapsed(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })

  const tap = (no) => {
    cycle(no)
    setFlipping(no)
    setTimeout(() => setFlipping(f => f === no ? null : f), 360)
  }

  const matchesFilter = (no) => {
    if (searchHits && !searchHits.has(no)) return false
    if (statusFilter === 'all') return true
    const st = statusMap.get(no)
    if (statusFilter === 'missing') return st === undefined
    return st === statusFilter
  }

  const visibleSections = useMemo(() => {
    let secs = SECTIONS
    if (nav === 'intro') secs = SECTIONS.filter(s => s.id === 'intro')
    else if (nav === 'museum') secs = SECTIONS.filter(s => s.id === 'museum')
    else if (nav === 'extra') secs = SECTIONS.filter(s => s.id === 'extra')
    else if (['america', 'europe', 'afrasia'].includes(nav)) secs = SECTIONS.filter(s => s.conf === nav)
    return secs
  }, [nav])

  const completion = (sec) => {
    let owned = 0
    for (let n = sec.from; n <= sec.to; n++) if (statusMap.has(n)) owned++
    const total = sec.to - sec.from + 1
    return { owned, total, pct: Math.round((owned / total) * 100) }
  }

  if (loading) return (
    <div className="p-4 lg:p-8">
      <Skeleton className="h-10 w-48 mb-4" />
      <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-8 xl:grid-cols-10 gap-1.5">
        {Array.from({ length: 40 }).map((_, i) => <Skeleton key={i} className="aspect-[3/4]" />)}
      </div>
    </div>
  )

  return (
    <div className="flex flex-col h-full">
      {/* Sticky Header */}
      <div className="sticky top-0 z-20 bg-bg/95 backdrop-blur border-b border-white/10 px-4 lg:px-8 pt-4 pb-2 flex flex-col gap-2">
        <div className="flex items-end justify-between">
          <h1 className="font-display text-4xl text-gold">Album</h1>
          <span className="font-display text-2xl text-white/70">
            {counts.owned}<span className="text-white/30 text-base">/{TOTAL_STICKERS}</span>
          </span>
        </div>

        {/* Suche */}
        <div className="flex items-center gap-2 bg-card border border-white/15 rounded-xl px-3 focus-within:border-gold">
          <Search size={15} className="text-white/40 shrink-0" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Suche: ARG17, Messi, Deutschland, FWC9…"
            className="flex-1 bg-transparent py-2.5 text-sm outline-none placeholder:text-white/30"
            autoComplete="off"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-white/40 hover:text-white" aria-label="Suche löschen">
              <X size={14} />
            </button>
          )}
        </div>

        {/* Navigation */}
        <div className="flex gap-1.5 overflow-x-auto pb-1" role="tablist" aria-label="Sektion">
          {NAV.map(n => (
            <button
              key={n.id}
              onClick={() => setNav(n.id)}
              role="tab"
              aria-selected={nav === n.id}
              className={`shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                nav === n.id ? 'bg-gold text-bg border-gold font-bold' : 'bg-card text-white/60 border-white/15 hover:border-white/40'
              }`}
            >
              <span>{n.icon}</span><span>{n.label}</span>
            </button>
          ))}
        </div>

        {/* Status-Filter */}
        <div className="flex gap-1.5 overflow-x-auto" role="tablist" aria-label="Status">
          {STATUS_FILTERS.map(f => (
            <button
              key={f.id}
              onClick={() => setStatusFilter(f.id)}
              role="tab"
              aria-selected={statusFilter === f.id}
              className={`shrink-0 px-2.5 py-1 rounded-full border text-[11px] font-medium ${
                statusFilter === f.id ? 'bg-gold/20 text-gold border-gold/50' : 'bg-card text-white/50 border-white/10'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Sektionen */}
      <div className="flex-1 overflow-y-auto p-4 lg:p-8 pt-3 flex flex-col gap-4">
        {visibleSections.map((sec) => {
          const nums = []
          for (let n = sec.from; n <= sec.to; n++) if (matchesFilter(n)) nums.push(n)
          // Bei Suche oder Statusfilter: leere Sektionen ausblenden
          if (nums.length === 0 && (searchHits || statusFilter !== 'all')) return null
          const { owned, total, pct } = completion(sec)
          const isCollapsed = collapsed.has(sec.id) && !searchHits

          return (
            <section key={sec.id} className={`bg-card border rounded-2xl overflow-hidden ${
              sec.extra ? 'border-gold/40' : 'border-white/10'
            }`}>
              {/* Sektion-Header */}
              <button
                onClick={() => toggleCollapse(sec.id)}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5"
              >
                <span className="text-xl">{sec.flag ?? sec.icon}</span>
                <div className="flex-1 text-left min-w-0">
                  <div className="flex items-baseline gap-2 flex-wrap">
                    <span className="font-display text-lg leading-tight">{sec.name}</span>
                    {sec.isTeam && (
                      <span className="text-[10px] font-mono text-white/40">{sec.code}1–{sec.code}20</span>
                    )}
                    {sec.foil && (
                      <span className="text-[9px] font-bold bg-gold/20 text-gold px-1.5 py-0.5 rounded">FOIL</span>
                    )}
                    {sec.extra && (
                      <span className="text-[9px] font-bold bg-gold/30 text-gold px-1.5 py-0.5 rounded">1:100 PACKS</span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-1 bg-bg rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all"
                        style={{ width: `${pct}%`, background: pct === 100 ? '#00ff88' : '#FFD700' }} />
                    </div>
                    <span className="text-[10px] font-mono text-white/40 shrink-0">{owned}/{total}</span>
                  </div>
                </div>
                {!sec.extra && (
                  <span
                    role="button"
                    tabIndex={0}
                    onClick={(e) => { e.stopPropagation(); markSectionHave(sec.from, sec.to) }}
                    onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); markSectionHave(sec.from, sec.to) } }}
                    className="text-white/30 hover:text-gold px-1.5 py-1 shrink-0 cursor-pointer"
                    title="Alle als vorhanden markieren"
                  >
                    <CheckCheck size={13} />
                  </span>
                )}
                {isCollapsed ? <ChevronDown size={16} className="text-white/40 shrink-0" /> : <ChevronUp size={16} className="text-white/40 shrink-0" />}
              </button>

              {/* Grid */}
              {!isCollapsed && nums.length > 0 && (
                <div className="px-3 pb-3 grid grid-cols-4 sm:grid-cols-5 md:grid-cols-7 xl:grid-cols-10 gap-1.5">
                  {nums.map((no) => {
                    const st = statusMap.get(no)
                    const foil = isFoil(no)
                    const extra = isExtra(no)
                    const key = isKeyPlayer(no)
                    const code = stickerCode(no)
                    const label = stickerLabel(no)

                    return (
                      <button
                        key={no}
                        onClick={() => tap(no)}
                        aria-label={`${code} ${label ?? ''}: ${st === 'have' ? 'vorhanden' : st === 'double' ? 'doppelt' : 'fehlend'}`}
                        title={label ?? code}
                        className={`relative aspect-[3/4] rounded-lg flex flex-col items-center justify-between p-1 select-none transition-all focus-visible:outline focus-visible:outline-gold ${
                          flipping === no ? 'animate-flip' : ''
                        } ${(foil || extra) ? 'shine-sticker' : 'border border-white/10'} ${
                          st === 'have' ? 'bg-primary/40 border-primary/60'
                          : st === 'double' ? 'bg-double/20 border-double/50'
                          : 'bg-card opacity-60'
                        }`}
                      >
                        <div className="self-start flex gap-0.5">
                          {key && <span className="text-[8px]">⭐</span>}
                          {extra && <span className="text-[8px]">💎</span>}
                        </div>
                        <span className="text-base leading-none">
                          {st === 'have' ? '✅' : st === 'double' ? '🔄' : '❌'}
                        </span>
                        <div className="w-full text-center">
                          <span className={`font-mono text-[9px] leading-none block truncate ${
                            (foil || extra) ? 'text-gold font-bold' : 'text-white/70'
                          }`}>
                            {code}
                          </span>
                          {label && (key || extra || no <= 9 || no >= 970) && (
                            <span className="text-[7px] text-white/45 block truncate leading-tight">
                              {label}
                            </span>
                          )}
                        </div>
                      </button>
                    )
                  })}
                </div>
              )}
            </section>
          )
        })}

        {/* Kein Suchtreffer */}
        {searchHits && visibleSections.every(sec => {
          for (let n = sec.from; n <= sec.to; n++) if (matchesFilter(n)) return false
          return true
        }) && (
          <div className="text-center py-10 text-white/40 text-sm">
            Keine Treffer für „{query}" — versuch z. B. <span className="font-mono text-gold">ARG17</span> oder <span className="text-gold">Messi</span>
          </div>
        )}
      </div>
    </div>
  )
}
