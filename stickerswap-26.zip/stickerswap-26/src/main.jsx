import React from 'react'
import ReactDOM from 'react-dom/client'
import { inject } from '@vercel/analytics'
import App from './App'
import { AuthProvider } from './hooks/useAuth'
import { ToastProvider } from './hooks/useToast'
import InstallPrompt from './components/InstallPrompt'
import './index.css'

inject()

class ErrorBoundary extends React.Component {
  state = { error: null }
  static getDerivedStateFromError(error) {
    return { error }
  }
  render() {
    if (this.state.error) {
      return (
        <div className="min-h-dvh flex items-center justify-center p-6 text-center">
          <div>
            <div className="text-5xl mb-3">😵</div>
            <h1 className="font-display text-3xl text-gold mb-2">Da ist etwas schiefgelaufen</h1>
            <p className="text-sm text-white/55 mb-4">Lade die Seite neu – deine Daten sind sicher gespeichert.</p>
            <button
              onClick={() => window.location.reload()}
              className="bg-gold text-bg font-bold rounded-xl px-6 py-2.5 text-sm"
            >
              Neu laden
            </button>
          </div>
        </div>
      )
    }
    return this.props.children
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ErrorBoundary>
      <ToastProvider>
        <AuthProvider>
          <div className="ball-pattern" aria-hidden="true" />
          <App />
          <InstallPrompt />
        </AuthProvider>
      </ToastProvider>
    </ErrorBoundary>
  </React.StrictMode>,
)
