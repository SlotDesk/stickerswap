import { useState } from 'react'
import { useAuth } from './hooks/useAuth'
import { useStickers } from './hooks/useStickers'
import { useMatches, useTrades } from './hooks/useTrades'
import { Skeleton } from './components/ui'
import Layout from './components/Layout'
import Login from './pages/Login'
import Onboarding from './pages/Onboarding'
import HomePage from './pages/Home'
import MapPage from './pages/MapView'
import AlbumPage from './pages/Album'
import TradesPage from './pages/Trades'
import ProfilePage from './pages/ProfilePage'

export default function App() {
  const { session, profile, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-dvh flex items-center justify-center">
        <div className="flex flex-col items-center gap-4 w-full max-w-sm p-6">
          <span className="text-5xl">⚽</span>
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    )
  }

  if (!session) return <Login />
  if (!profile) return <Onboarding />

  return <Shell profile={profile} />
}

function Shell({ profile }) {
  const [tab, setTab] = useState('home')
  const stickers = useStickers()
  const { matches, reload: reloadMatches } = useMatches()
  const tradesApi = useTrades()
  const { user } = useAuth()

  return (
    <Layout tab={tab} setTab={setTab} badge={tradesApi.incomingPending.length}>
      {tab === 'home' && (
        <HomePage
          profile={profile}
          counts={stickers.counts}
          stickersLoading={stickers.loading}
          statusMap={stickers.statusMap}
          matches={matches}
          incomingPending={tradesApi.incomingPending}
          setTab={setTab}
        />
      )}
      {tab === 'map' && <MapPage profile={profile} matches={matches} />}
      {tab === 'album' && (
        <AlbumPage
          statusMap={stickers.statusMap}
          cycle={stickers.cycle}
          markSectionHave={stickers.markSectionHave}
          counts={stickers.counts}
          loading={stickers.loading}
        />
      )}
      {tab === 'trades' && (
        <TradesPage
          matches={matches}
          reloadMatches={reloadMatches}
          trades={tradesApi.trades}
          accept={tradesApi.accept}
          decline={tradesApi.decline}
          request={tradesApi.request}
          incomingPending={tradesApi.incomingPending}
          userId={user.id}
        />
      )}
      {tab === 'profile' && (
        <ProfilePage profile={profile} counts={stickers.counts} statusMap={stickers.statusMap} trades={tradesApi.trades} />
      )}
    </Layout>
  )
}
