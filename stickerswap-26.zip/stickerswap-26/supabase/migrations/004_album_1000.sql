-- Sticker 1–1000, Radius bis 200 km (bereits auf Live-DB angewendet)
ALTER TABLE public.sticker_status DROP CONSTRAINT sticker_status_sticker_no_check;
ALTER TABLE public.sticker_status ADD CONSTRAINT sticker_status_sticker_no_check CHECK (sticker_no BETWEEN 1 AND 1000);
ALTER TABLE public.profiles DROP CONSTRAINT profiles_radius_km_check;
ALTER TABLE public.profiles ADD CONSTRAINT profiles_radius_km_check CHECK (radius_km BETWEEN 1 AND 200);
