-- StickerSwap 26 – Schema, RLS & Funktionen
-- =========================================

-- ---------- Tabellen ----------

create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  name text not null check (char_length(name) between 1 and 40),
  avatar_emoji text not null default '⚽',
  city text not null,
  lat double precision not null,
  lng double precision not null,
  radius_km int not null default 25 check (radius_km between 1 and 100),
  is_bot boolean not null default false,
  created_at timestamptz not null default now()
);

-- 'missing' wird NICHT gespeichert (keine Zeile = fehlend)
create table public.sticker_status (
  user_id uuid not null references public.profiles(id) on delete cascade,
  sticker_no int not null check (sticker_no between 1 and 400),
  status text not null check (status in ('have','double')),
  primary key (user_id, sticker_no)
);
create index sticker_status_status_idx on public.sticker_status (status, sticker_no);

create table public.trades (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  partner_id uuid not null references public.profiles(id) on delete cascade,
  give_stickers int[] not null,  -- aus Sicht des Requesters
  get_stickers int[] not null,
  message text,
  status text not null default 'pending' check (status in ('pending','accepted','declined')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (requester_id <> partner_id),
  check (array_length(give_stickers,1) >= 1 and array_length(get_stickers,1) >= 1)
);
create index trades_partner_idx on public.trades (partner_id, status);
create index trades_requester_idx on public.trades (requester_id, status);

create table public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  message text not null check (char_length(message) between 1 and 2000),
  email text,
  created_at timestamptz not null default now()
);

-- ---------- RLS ----------

alter table public.profiles enable row level security;
alter table public.sticker_status enable row level security;
alter table public.trades enable row level security;
alter table public.feedback enable row level security;

-- profiles: alle eingeloggten lesen (Matching), nur eigene Zeile schreiben
create policy "profiles read" on public.profiles
  for select to authenticated using (true);
create policy "profiles insert own" on public.profiles
  for insert to authenticated with check (id = auth.uid() and is_bot = false);
create policy "profiles update own" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and is_bot = false);

-- sticker_status: alle lesen, nur eigene schreiben
create policy "stickers read" on public.sticker_status
  for select to authenticated using (true);
create policy "stickers insert own" on public.sticker_status
  for insert to authenticated with check (user_id = auth.uid());
create policy "stickers update own" on public.sticker_status
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "stickers delete own" on public.sticker_status
  for delete to authenticated using (user_id = auth.uid());

-- trades: nur Beteiligte lesen; nur Requester erstellt; nur Partner ändert Status (decline direkt, accept via RPC)
create policy "trades read involved" on public.trades
  for select to authenticated using (requester_id = auth.uid() or partner_id = auth.uid());
create policy "trades insert as requester" on public.trades
  for insert to authenticated with check (requester_id = auth.uid());
create policy "trades partner declines" on public.trades
  for update to authenticated
  using (partner_id = auth.uid() and status = 'pending')
  with check (partner_id = auth.uid() and status = 'declined');

-- feedback: nur einfügen (eigene user_id oder anonym), niemand liest per Client
create policy "feedback insert" on public.feedback
  for insert to authenticated with check (user_id is null or user_id = auth.uid());

-- ---------- Funktion: Trade atomar akzeptieren ----------
-- Beim Geber: double -> have. Beim Empfänger: Zeile 'have' anlegen (falls fehlend).

create or replace function public._apply_trade_inventory(p_giver uuid, p_receiver uuid, p_stickers int[])
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  -- Geber: doppelt wird zu vorhanden
  update sticker_status
     set status = 'have'
   where user_id = p_giver
     and sticker_no = any(p_stickers)
     and status = 'double';

  -- Empfänger: fehlende Sticker werden zu vorhanden (vorhandene bleiben unberührt)
  insert into sticker_status (user_id, sticker_no, status)
  select p_receiver, s, 'have' from unnest(p_stickers) as s
  on conflict (user_id, sticker_no) do nothing;
end;
$$;

create or replace function public.accept_trade(p_trade_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  t record;
begin
  select * into t from trades where id = p_trade_id for update;

  if t is null then
    raise exception 'Trade nicht gefunden';
  end if;
  if t.partner_id <> auth.uid() then
    raise exception 'Nur der Empfänger kann annehmen';
  end if;
  if t.status <> 'pending' then
    raise exception 'Trade ist nicht mehr offen';
  end if;

  update trades set status = 'accepted', updated_at = now() where id = p_trade_id;

  -- Requester gibt give_stickers an Partner
  perform _apply_trade_inventory(t.requester_id, t.partner_id, t.give_stickers);
  -- Partner gibt get_stickers an Requester
  perform _apply_trade_inventory(t.partner_id, t.requester_id, t.get_stickers);
end;
$$;

revoke all on function public.accept_trade(uuid) from public;
grant execute on function public.accept_trade(uuid) to authenticated;
revoke all on function public._apply_trade_inventory(uuid, uuid, int[]) from public, authenticated;

-- ---------- Funktion: Matching ----------

create or replace function public.find_matches(p_user_id uuid)
returns table (
  user_id uuid,
  name text,
  avatar_emoji text,
  city text,
  lat double precision,
  lng double precision,
  is_bot boolean,
  distance_km int,
  i_give int[],
  i_get int[],
  score int
)
language sql
security definer
set search_path = public
stable
as $$
  with me as (
    -- nur das eigene Profil; liefert leer, wenn p_user_id nicht der eingeloggte Nutzer ist
    select * from profiles where id = p_user_id and id = auth.uid()
  ),
  others as (
    select p.*,
      round(6371 * acos(least(1, greatest(-1,
        cos(radians(me.lat)) * cos(radians(p.lat)) *
        cos(radians(p.lng) - radians(me.lng)) +
        sin(radians(me.lat)) * sin(radians(p.lat))
      ))))::int as dist
    from profiles p, me
    where p.id <> me.id
  ),
  in_range as (
    select o.* from others o, me
    where o.dist <= least(me.radius_km, o.radius_km)
  ),
  pairs as (
    select
      r.id, r.name, r.avatar_emoji, r.city, r.lat, r.lng, r.is_bot, r.dist,
      coalesce((
        select array_agg(s.sticker_no order by s.sticker_no)
        from sticker_status s
        where s.user_id = p_user_id and s.status = 'double'
          and not exists (select 1 from sticker_status x where x.user_id = r.id and x.sticker_no = s.sticker_no)
      ), '{}') as i_give,
      coalesce((
        select array_agg(s.sticker_no order by s.sticker_no)
        from sticker_status s
        where s.user_id = r.id and s.status = 'double'
          and not exists (select 1 from sticker_status x where x.user_id = p_user_id and x.sticker_no = s.sticker_no)
      ), '{}') as i_get
    from in_range r
  )
  select
    id, name, avatar_emoji, city, lat, lng, is_bot, dist,
    i_give, i_get,
    least(coalesce(array_length(i_give,1),0), coalesce(array_length(i_get,1),0)) as score
  from pairs
  where coalesce(array_length(i_give,1),0) > 0 and coalesce(array_length(i_get,1),0) > 0
  order by score desc, dist asc;
$$;

revoke all on function public.find_matches(uuid) from public;
grant execute on function public.find_matches(uuid) to authenticated;

-- ---------- Funktion: Bot-Trades verarbeiten ----------
-- Client ruft das beim Laden auf: Bots akzeptieren offene Anfragen, die älter als 30 s sind.

create or replace function public.process_bot_trades()
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  t record;
  n int := 0;
begin
  for t in
    select tr.id from trades tr
    join profiles p on p.id = tr.partner_id
    where tr.requester_id = auth.uid()
      and tr.status = 'pending'
      and p.is_bot
      and tr.created_at < now() - interval '30 seconds'
    for update of tr skip locked
  loop
    update trades set status = 'accepted', updated_at = now() where id = t.id;
    perform _apply_trade_inventory(
      (select requester_id from trades where id = t.id),
      (select partner_id from trades where id = t.id),
      (select give_stickers from trades where id = t.id));
    perform _apply_trade_inventory(
      (select partner_id from trades where id = t.id),
      (select requester_id from trades where id = t.id),
      (select get_stickers from trades where id = t.id));
    n := n + 1;
  end loop;
  return n;
end;
$$;

revoke all on function public.process_bot_trades() from public;
grant execute on function public.process_bot_trades() to authenticated;

-- ---------- Realtime für Trades ----------
alter publication supabase_realtime add table public.trades;
