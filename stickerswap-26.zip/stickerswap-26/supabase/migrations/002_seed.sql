-- StickerSwap 26 – Seed: 12 Demo-Bots über DACH verteilt
-- Bots sind echte auth.users-Zeilen (Dummy-Adressen, kein Login möglich,
-- da encrypted_password leer und E-Mail-Domain reserviert ist).

do $$
declare
  bots constant jsonb := '[
    {"name":"Mia 🤖","emoji":"🦊","city":"Berlin","lat":52.52,"lng":13.405},
    {"name":"Leon 🤖","emoji":"🦁","city":"Hamburg","lat":53.5511,"lng":9.9937},
    {"name":"Emma 🤖","emoji":"🐝","city":"München","lat":48.1351,"lng":11.582},
    {"name":"Noah 🤖","emoji":"🐺","city":"Köln","lat":50.9375,"lng":6.9603},
    {"name":"Lina 🤖","emoji":"🦋","city":"Frankfurt","lat":50.1109,"lng":8.6821},
    {"name":"Paul 🤖","emoji":"🐻","city":"Stuttgart","lat":48.7758,"lng":9.1829},
    {"name":"Clara 🤖","emoji":"🐱","city":"Leipzig","lat":51.3397,"lng":12.3731},
    {"name":"Finn 🤖","emoji":"🦅","city":"Hannover","lat":52.3759,"lng":9.732},
    {"name":"Sophie 🤖","emoji":"🐬","city":"Wien","lat":48.2082,"lng":16.3738},
    {"name":"Luca 🤖","emoji":"🐯","city":"Zürich","lat":47.3769,"lng":8.5417},
    {"name":"Anna 🤖","emoji":"🦉","city":"Graz","lat":47.0707,"lng":15.4395},
    {"name":"Ben 🤖","emoji":"🐢","city":"Nürnberg","lat":49.4521,"lng":11.0767}
  ]';
  b jsonb;
  uid uuid;
  i int := 0;
  s int;
  r double precision;
begin
  for b in select * from jsonb_array_elements(bots) loop
    i := i + 1;
    uid := gen_random_uuid();

    insert into auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, created_at, updated_at,
      raw_app_meta_data, raw_user_meta_data
    ) values (
      '00000000-0000-0000-0000-000000000000', uid, 'authenticated', 'authenticated',
      'bot' || i || '@stickerswap26.invalid', '',
      now(), now(), now(),
      '{"provider":"email","providers":["email"]}', '{}'
    );

    insert into public.profiles (id, name, avatar_emoji, city, lat, lng, radius_km, is_bot)
    values (uid, b->>'name', b->>'emoji', b->>'city',
            (b->>'lat')::double precision, (b->>'lng')::double precision,
            60, true);

    -- Inventar: pro Sticker ~60 % have, davon ein Teil double (~15 % gesamt)
    for s in 1..400 loop
      r := random();
      if r < 0.15 then
        insert into public.sticker_status values (uid, s, 'double');
      elsif r < 0.60 then
        insert into public.sticker_status values (uid, s, 'have');
      end if;
    end loop;
  end loop;
end $$;
