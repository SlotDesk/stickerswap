# StickerSwap 26 – Projektkontext für Claude Code

Inoffizielle Tausch-App für WM-2026-Sticker (Testphase, 0-€-Setup). Der Besitzer ist kein Entwickler — erkläre Schritte einfach und führe Befehle wo möglich selbst aus.

## Stack & Deployment

- **Frontend:** Vite + React 18, Tailwind CSS, lucide-react, recharts, Leaflet (via CDN geladen, kein npm-Paket)
- **Backend:** Supabase — Projekt-Ref `gprdevgpventszpxnfnv` (Region eu-central-1), URL `https://gprdevgpventszpxnfnv.supabase.co`
- **Deployment:** Vercel, Projekt `stickerswap-26` (Scope: SlotDesk's projects). Deploy: `npx vercel --prod`
- **Env:** `.env.production` enthält `VITE_SUPABASE_URL` + `VITE_SUPABASE_ANON_KEY` (publishable Key, darf im Repo liegen — Sicherheit kommt aus RLS)
- Build-Check: `npm run build` (muss vor jedem Deploy fehlerfrei sein)

## Album-Struktur (WICHTIG: eingefroren, nicht mehr ändern!)

1000 Sticker, interne Nummerierung 1–1000. Mapping in `src/lib/constants.js`:

- **1–9:** Intro/Foil — Codes `00`, `FWC1`–`FWC8` (Logo, Emblem, 3 Maskottchen, Spielball, 3 Gastgeber)
- **10–969:** 48 Teams à 20 Sticker in offizieller Album-Reihenfolge: MEX, RSA, KOR, CZE, CAN, BIH, QAT, SUI, BRA, MAR, HAI, SCO, USA, PAR, AUS, TUR, GER, CUW, CIV, ECU, NED, JPN, SWE, TUN, BEL, EGY, IRN, NZL, ESP, CPV, KSA, URU, FRA, SEN, IRQ, NOR, ARG, ALG, AUT, JOR, POR, COD, UZB, COL, ENG, CRO, GHA, PAN. Codes: `MEX1`–`MEX20` etc. Slot 1 = Team-Logo (Foil), Slot 13 = Team-Foto, Rest Spieler.
- **970–980:** WM-Museum/Foil — `FWC9`–`FWC19` (Weltmeister-Historie)
- **981–1000:** Extra-Subset (`EX1`–`EX20`), ultra-rare, 20 Star-Spieler. Farbstufen (bronze/silver/gold) NICHT implementiert.
- Key-Player mit Namen: ARG17 Messi, POR15 Ronaldo, FRA20 Mbappé, NOR15 Haaland, BRA14 Vinícius, ENG11 Bellingham, ESP15 Yamal, GER19 Wirtz, MEX17 Jiménez, USA9 Pulisic, COL10 Luis Díaz, MAR2 Hakimi, KOR11 Son, EGY10 Salah
- Die Album-Reihenfolge darf NICHT mehr geändert werden, sonst verschieben sich die Sammlungen echter Nutzer (sticker_no ist der Speicher-Key).

## Markenrecht (strikt einhalten)

Kein "Panini", kein "FIFA", keine offiziellen Maskottchen-Namen, keine offiziellen Assets in UI/Code. Spielernamen sind als Fakten ok. Slot-Bezeichnungen generisch halten ("Logo", "Emblem", "Maskottchen I").

## Datenbank (Supabase, bereits live migriert)

Tabellen: `profiles` (id=auth.uid, name, avatar_emoji, city, lat, lng, radius_km 1–200, is_bot), `sticker_status` (user_id, sticker_no 1–1000, status 'have'|'double'; fehlend = keine Zeile!), `trades` (give_stickers int[], get_stickers int[], status pending/accepted/declined), `feedback`.

RPC-Funktionen (SECURITY DEFINER): `find_matches(p_user_id)` (Haversine + Mengenlogik serverseitig), `accept_trade(p_trade_id)` (atomar, nur Partner), `process_bot_trades()` (Bots akzeptieren nach 30 s, Client ruft beim Laden auf). Realtime auf `trades` aktiv. RLS überall, anon hat keine Execute-Rechte.

12 Demo-Bots (Name endet auf 🤖, is_bot=true) mit ~60 % Inventar, Extras nur ~7 %.

Migrationen liegen in `supabase/migrations/` (001–004, alle bereits angewendet). Schema-Änderungen: SQL im Supabase-Dashboard (SQL-Editor) ausführen UND als neue Migrationsdatei ablegen.

## Architektur-Entscheidungen

- Sticker-Writes sind 800 ms gebatcht mit optimistic UI (`src/hooks/useStickers.js`) — nie pro Tap ein Roundtrip
- Matching läuft NUR serverseitig (`find_matches`), Client zeigt an
- Inventar-Updates bei Trade-Accept NUR über `accept_trade()` RPC, nie client-seitig
- Leaflet wird zur Laufzeit von cdnjs geladen (window.L), Karten-Tiles: CARTO dark
- Standortwahl: `src/components/LocationPicker.jsx` (Nominatim-Suche + Karten-Klick)
- Keine Browser-Storage-APIs außer dem install-dismissed-Flag

## Status / offene Punkte

- App ist live deployt, Supabase-Backend vollständig eingerichtet
- Auth-Redirect-URL in Supabase muss auf die Vercel-Domain zeigen (Authentication → URL Configuration)
- Post-MVP-Ideen (bewusst noch nicht gebaut): Credits/Pricing (5 Anfragen/Woche frei, Saison-Pass), Push-Notifications, Chat, Extra-Sticker-Farbstufen, Leaderboard
- Vercel Analytics ggf. im Dashboard aktivieren
