# StickerSwap 26 ⚽

Inoffizielle Tausch-App für WM-2026-Sticker. Vite + React 18 + Tailwind, Supabase (Auth, Postgres + RLS, Realtime), deploybar auf Vercel. Kosten in der Testphase: 0 €.

## Setup

1. **Supabase-Projekt anlegen** (Free Tier reicht).
2. SQL ausführen (SQL-Editor oder CLI):
   - `supabase/migrations/001_schema.sql` – Tabellen, RLS, `accept_trade`, `find_matches`, `process_bot_trades`, Realtime
   - `supabase/migrations/002_seed.sql` – 12 Demo-Bots mit Inventar
3. **Auth**: E-Mail-Provider (Magic Link) ist standardmäßig aktiv. Unter *Authentication → URL Configuration* die Vercel-Domain als Site-URL und Redirect-URL eintragen.
4. Env-Variablen setzen (lokal in `.env`, auf Vercel im Projekt):
   ```
   VITE_SUPABASE_URL=https://<projekt>.supabase.co
   VITE_SUPABASE_ANON_KEY=<anon-key>
   ```
5. Lokal: `npm install && npm run dev` · Deploy: Repo mit Vercel verbinden (Framework: Vite) oder `vercel deploy`.

## Architektur-Notizen

- **Inventar**: nur `have`/`double` werden gespeichert; *fehlend* = keine Zeile. Writes sind 800 ms gebatcht (optimistic UI).
- **Matching**: komplett serverseitig in `find_matches(p_user_id)` (Haversine + Mengenlogik), Client zeigt nur an.
- **Trades**: `accept_trade()` (SECURITY DEFINER) aktualisiert beide Inventare atomar. Decline läuft über RLS-beschränktes Update.
- **Bots**: `process_bot_trades()` wird beim Laden des Tausch-Tabs aufgerufen und akzeptiert offene Anfragen an Bots nach 30 s.
- **Realtime**: `trades` ist in der `supabase_realtime`-Publication; der Posteingang aktualisiert sich live.
- **Feedback**: landet in der `feedback`-Tabelle (nur Insert per Client; auslesen im Supabase-Dashboard).

## Testphase auswerten

- Feedback: `select * from feedback order by created_at desc;`
- Aktivität: `select count(*) from trades where status='accepted';`
- Vercel Analytics im Dashboard (Seitenaufrufe, Absprünge).

## Rechtliches

Kein geschützter Markenname, keine offiziellen Assets, keine echten Spielernamen. Sticker sind Nummern + generische Sektionen ("Gruppe A · Team A2").
